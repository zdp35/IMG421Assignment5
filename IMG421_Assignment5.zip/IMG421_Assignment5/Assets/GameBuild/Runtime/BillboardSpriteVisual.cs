using UnityEngine;

public class BillboardSpriteVisual : MonoBehaviour
{
    [SerializeField] private string resourcePath;
    [SerializeField] private Vector2 sizeMultiplier = Vector2.one;
    [SerializeField] private int sortingOrder = 5;
    [SerializeField] private bool hideOriginalRenderer = true;

    private GameObject spriteChild;
    private SpriteRenderer spriteRenderer;
    private Renderer originalRenderer;

    void Awake()
    {
        originalRenderer = GetComponent<Renderer>();
        EnsureSpriteObject();
        if (hideOriginalRenderer && originalRenderer != null)
        {
            originalRenderer.enabled = false;
        }
        if (!string.IsNullOrEmpty(resourcePath))
        {
            SetSpriteFromResources(resourcePath);
        }
        FitToCollider();
    }

    void LateUpdate()
    {
        if (spriteChild == null || Camera.main == null) return;
        Vector3 forward = Camera.main.transform.forward;
        spriteChild.transform.rotation = Quaternion.LookRotation(forward, Vector3.up);
    }

    public void Configure(string path, Vector2 multiplier, int order = 5, bool hideRenderer = true)
    {
        resourcePath = path;
        sizeMultiplier = multiplier;
        sortingOrder = order;
        hideOriginalRenderer = hideRenderer;
        EnsureSpriteObject();
        if (hideOriginalRenderer && originalRenderer != null) originalRenderer.enabled = false;
        SetSpriteFromResources(path);
        FitToCollider();
    }

    public void SetSpriteFromResources(string path)
    {
        resourcePath = path;
        EnsureSpriteObject();
        Texture2D tex = Resources.Load<Texture2D>(path);
        if (tex == null) return;
        Sprite sprite = Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), new Vector2(0.5f, 0.5f), 100f);
        sprite.name = tex.name + "_RuntimeSprite";
        spriteRenderer.sprite = sprite;
        spriteRenderer.sortingOrder = sortingOrder;
        FitToCollider();
    }

    public void SetTint(Color color)
    {
        EnsureSpriteObject();
        spriteRenderer.color = color;
    }

    private void EnsureSpriteObject()
    {
        if (spriteChild != null && spriteRenderer != null) return;
        Transform existing = transform.Find("SpriteVisual");
        if (existing != null)
        {
            spriteChild = existing.gameObject;
            spriteRenderer = existing.GetComponent<SpriteRenderer>();
        }
        if (spriteChild == null)
        {
            spriteChild = new GameObject("SpriteVisual");
            spriteChild.transform.SetParent(transform, false);
            spriteChild.transform.localPosition = Vector3.zero;
            spriteChild.transform.localRotation = Quaternion.identity;
            spriteRenderer = spriteChild.AddComponent<SpriteRenderer>();
        }
    }

    private void FitToCollider()
    {
        if (spriteChild == null || spriteRenderer == null || spriteRenderer.sprite == null) return;
        Bounds bounds = new Bounds(transform.position, Vector3.one);
        Collider col = GetComponent<Collider>();
        if (col != null) bounds = col.bounds;
        else if (originalRenderer != null) bounds = originalRenderer.bounds;

        float width = Mathf.Max(0.5f, bounds.size.x) * sizeMultiplier.x;
        float height = Mathf.Max(0.5f, bounds.size.y) * sizeMultiplier.y;
        spriteChild.transform.localScale = new Vector3(width, height, 1f);
        spriteChild.transform.localPosition = new Vector3(0f, 0f, -0.05f);
    }
}
