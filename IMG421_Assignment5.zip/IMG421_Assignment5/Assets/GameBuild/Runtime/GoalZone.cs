using UnityEngine;

[RequireComponent(typeof(Collider))]
public class GoalZone : MonoBehaviour
{
    public static bool goalMet = false;

    [SerializeField] private ParticleSystem successParticles;
    [SerializeField] private SpriteRenderer spriteRenderer;
    [SerializeField] private Renderer meshRenderer;
    [SerializeField] private AudioSource sfxSource;
    [SerializeField] private AudioClip successClip;
    [SerializeField] private Color idleColor = new Color(0.35f, 1f, 0.45f, 0.92f);
    [SerializeField] private Color successColor = new Color(1f, 0.92f, 0.25f, 1f);
    [SerializeField] private float goalScaleMultiplier = 1.5f;

    private bool visualsBuilt;
    private BillboardSpriteVisual runtimeSprite;

    void Start()
    {
        goalMet = false;
        if (!spriteRenderer) spriteRenderer = GetComponent<SpriteRenderer>();
        if (!meshRenderer) meshRenderer = GetComponent<Renderer>();
        if (!sfxSource) sfxSource = gameObject.GetComponent<AudioSource>() ?? gameObject.AddComponent<AudioSource>();
        ApplyColor(idleColor);
        EnlargeGoal();
    }

    public static void ResetGoal() { goalMet = false; }

    void OnTriggerEnter(Collider other)
    {
        if (goalMet) return;
        if (other.GetComponent<Projectile>() == null) return;
        goalMet = true;
        ApplyColor(successColor);
        if (successParticles) successParticles.Play();
        RuntimeFeedback.SpawnImpact(transform.position, RuntimeFeedback.ImpactKind.Bounce);
        RuntimeFeedback.PlayGoal();
        if (sfxSource && successClip) sfxSource.PlayOneShot(successClip);
        if (GameSceneController.Instance) GameSceneController.Instance.WinLevel();
    }

    void ApplyColor(Color c)
    {
        if (spriteRenderer) spriteRenderer.color = c;
        if (meshRenderer && meshRenderer.material) meshRenderer.material.color = c;
    }

    void EnlargeGoal()
    {
        BoxCollider bc = GetComponent<BoxCollider>();
        if (!bc) return;

        Vector3 size = bc.size;
        size.x = Mathf.Max(size.x * 1.35f, 1.35f);
        size.y = Mathf.Max(size.y * 1.85f, 1.85f);
        size.z = Mathf.Max(size.z * 1.2f, 1.2f);
        bc.size = size;
        bc.center = new Vector3(0f, 0.2f, 0f);
    }

}
