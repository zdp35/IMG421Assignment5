using UnityEngine;

public class ProjectileSpinVisual : MonoBehaviour
{
    [SerializeField] private float spinSpeed = 220f;

    void Update()
    {
        transform.Rotate(0f, 0f, spinSpeed * Time.deltaTime, Space.Self);
    }
}
