using UnityEngine;

public class IdleBobAnimation : MonoBehaviour
{
    [SerializeField] private float bobAmount = 0.08f;
    [SerializeField] private float bobSpeed = 1.8f;
    private Vector3 startLocalPosition;

    void Awake()
    {
        startLocalPosition = transform.localPosition;
    }

    void Update()
    {
        transform.localPosition = startLocalPosition + Vector3.up * (Mathf.Sin(Time.time * bobSpeed) * bobAmount);
    }
}
