using UnityEngine;

public class FrostedGlassVisual : MonoBehaviour
{
    [SerializeField] private Color tint = new Color(0.12f, 0.74f, 1f, 0.72f);
    [SerializeField] private Color highlight = new Color(0.92f, 0.98f, 1f, 0.34f);

    private Renderer cachedRenderer;
    private Transform sheen;

    void Awake()
    {
        cachedRenderer = GetComponent<Renderer>();
        ApplyBaseMaterial();
        EnsureSheen();
    }

    private void ApplyBaseMaterial()
    {
        if (cachedRenderer == null || cachedRenderer.material == null) return;
        Material mat = cachedRenderer.material;
        mat.color = tint;
        if (mat.HasProperty("_Metallic")) mat.SetFloat("_Metallic", 0.05f);
        if (mat.HasProperty("_Glossiness")) mat.SetFloat("_Glossiness", 0.85f);
    }

    private void EnsureSheen()
    {
        Transform existing = transform.Find("GlassSheen");
        if (existing != null)
        {
            sheen = existing;
            return;
        }

        sheen = GameObject.CreatePrimitive(PrimitiveType.Cube).transform;
        sheen.name = "GlassSheen";
        sheen.SetParent(transform, false);
        sheen.localPosition = new Vector3(0f, 0f, -0.015f);
        sheen.localScale = new Vector3(0.16f, 1.02f, 0.04f);

        Collider col = sheen.GetComponent<Collider>();
        if (col != null) Destroy(col);

        Renderer rend = sheen.GetComponent<Renderer>();
        if (rend != null && rend.material != null)
        {
            rend.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            rend.receiveShadows = false;
            rend.material.color = highlight;
            if (rend.material.HasProperty("_Glossiness")) rend.material.SetFloat("_Glossiness", 1f);
        }
    }
}
