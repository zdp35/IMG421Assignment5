using UnityEngine;

public class SolidWallDetailVisual : MonoBehaviour
{
    [SerializeField] private Color wallColor = new Color(0.22f, 0.24f, 0.28f, 1f);
    [SerializeField] private Color boltColor = new Color(0.16f, 0.18f, 0.22f, 1f);
    [SerializeField] private Color seamColor = new Color(0.58f, 0.62f, 0.70f, 1f);

    private Renderer cachedRenderer;
    private Collider cachedCollider;
    private Transform decorRoot;

    void Awake()
    {
        cachedRenderer = GetComponent<Renderer>();
        cachedCollider = GetComponent<Collider>();
        ApplyBaseMaterial();
        BuildDecor();
    }

    private void ApplyBaseMaterial()
    {
        if (cachedRenderer == null || cachedRenderer.material == null) return;
        Material mat = cachedRenderer.material;
        mat.color = wallColor;
        if (mat.HasProperty("_Metallic")) mat.SetFloat("_Metallic", 0.55f);
        if (mat.HasProperty("_Glossiness")) mat.SetFloat("_Glossiness", 0.35f);
    }

    private void BuildDecor()
    {
        Transform existing = transform.Find("SolidWallDecor");
        if (existing != null)
        {
            decorRoot = existing;
            return;
        }

        decorRoot = new GameObject("SolidWallDecor").transform;
        decorRoot.SetParent(transform, false);

        Bounds bounds = cachedCollider != null ? cachedCollider.bounds : cachedRenderer != null ? cachedRenderer.bounds : new Bounds(transform.position, Vector3.one);
        Vector3 size = bounds.size;
        float width = Mathf.Max(0.6f, size.x);
        float height = Mathf.Max(0.6f, size.y);
        float depth = Mathf.Max(0.1f, size.z);

        CreateSeam(new Vector3(0f, 0f, -(depth * 0.5f + 0.005f)), new Vector3(width * 0.88f, Mathf.Max(0.025f, height * 0.03f), 0.02f));

        float x = Mathf.Clamp(width * 0.34f, 0.18f, 0.7f);
        float y = Mathf.Clamp(height * 0.34f, 0.18f, 0.7f);
        float z = -(depth * 0.5f + 0.01f);
        float boltSize = Mathf.Clamp(Mathf.Min(width, height) * 0.11f, 0.07f, 0.16f);

        CreateBolt(new Vector3(-x, y, z), boltSize);
        CreateBolt(new Vector3(x, y, z), boltSize);
        CreateBolt(new Vector3(-x, -y, z), boltSize);
        CreateBolt(new Vector3(x, -y, z), boltSize);
    }

    private void CreateBolt(Vector3 localPos, float size)
    {
        GameObject bolt = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        bolt.name = "Bolt";
        bolt.transform.SetParent(decorRoot, false);
        bolt.transform.localPosition = localPos;
        bolt.transform.localRotation = Quaternion.Euler(90f, 0f, 0f);
        bolt.transform.localScale = new Vector3(size, size * 0.18f, size);

        Collider boltCollider = bolt.GetComponent<Collider>();
        if (boltCollider != null) Destroy(boltCollider);

        Renderer rend = bolt.GetComponent<Renderer>();
        if (rend != null && rend.material != null)
        {
            rend.material.color = boltColor;
            if (rend.material.HasProperty("_Metallic")) rend.material.SetFloat("_Metallic", 0.8f);
            if (rend.material.HasProperty("_Glossiness")) rend.material.SetFloat("_Glossiness", 0.45f);
        }
    }

    private void CreateSeam(Vector3 localPos, Vector3 localScale)
    {
        GameObject seam = GameObject.CreatePrimitive(PrimitiveType.Cube);
        seam.name = "Seam";
        seam.transform.SetParent(decorRoot, false);
        seam.transform.localPosition = localPos;
        seam.transform.localScale = localScale;

        Collider seamCollider = seam.GetComponent<Collider>();
        if (seamCollider != null) Destroy(seamCollider);

        Renderer rend = seam.GetComponent<Renderer>();
        if (rend != null && rend.material != null)
        {
            rend.material.color = seamColor;
            if (rend.material.HasProperty("_Metallic")) rend.material.SetFloat("_Metallic", 0.15f);
            if (rend.material.HasProperty("_Glossiness")) rend.material.SetFloat("_Glossiness", 0.25f);
        }
    }
}
