using UnityEngine;

[RequireComponent(typeof(Collider))]
public class BreakableGlass : MonoBehaviour
{
    [SerializeField] private float breakVelocityThreshold = 7f;
    [SerializeField] private int hitsToBreak = 1;
    [SerializeField] private SpriteRenderer spriteRenderer;
    [SerializeField] private Renderer meshRenderer;
    [SerializeField] private Sprite intactSprite;
    [SerializeField] private Sprite crackedSprite;
    [SerializeField] private ParticleSystem breakParticles;
    [SerializeField] private AudioClip breakClip;
    [SerializeField] private AudioSource sfxSource;

    private int currentHits;
    private Collider cachedCollider;
    private BillboardSpriteVisual runtimeSprite;
    private bool breaking;

    void Awake()
    {
        cachedCollider = GetComponent<Collider>();
        currentHits = 0;
        if (!spriteRenderer) spriteRenderer = GetComponent<SpriteRenderer>();
        if (!meshRenderer) meshRenderer = GetComponent<Renderer>();
        if (!sfxSource) sfxSource = gameObject.GetComponent<AudioSource>() ?? gameObject.AddComponent<AudioSource>();
        runtimeSprite = GetComponent<BillboardSpriteVisual>();

        if (spriteRenderer) spriteRenderer.color = new Color(0.16f, 0.76f, 1f, 0.94f);
        if (meshRenderer && meshRenderer.material)
        {
            meshRenderer.material.color = new Color(0.16f, 0.76f, 1f, 0.94f);
        }
        if (cachedCollider)
        {
            cachedCollider.material = null;
        }
    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.GetComponent<Projectile>() == null) return;
        float impact = collision.rigidbody ? collision.rigidbody.velocity.magnitude : collision.relativeVelocity.magnitude;
        if (impact < breakVelocityThreshold) return;
        currentHits++;
        if (currentHits >= hitsToBreak) Break(collision);
        else ShowCrackedState();
    }

    void ShowCrackedState()
    {
        if (spriteRenderer && crackedSprite)
        {
            spriteRenderer.sprite = crackedSprite;
            spriteRenderer.color = new Color(0.34f, 0.88f, 1f, 0.96f);
        }
        if (meshRenderer && meshRenderer.material)
        {
            meshRenderer.material.color = new Color(0.62f, 0.92f, 1f, 0.96f);
        }
        if (runtimeSprite != null)
        {
            runtimeSprite.SetSpriteFromResources("GameBuild/Art/glass_cracked");
            runtimeSprite.SetTint(new Color(1f, 1f, 1f, 0.96f));
        }
    }

    void Break(Collision collision)
    {
        Vector3 position = collision.contactCount > 0 ? collision.GetContact(0).point : transform.position;
        if (breaking) return;
        breaking = true;

        if (breakParticles)
        {
            ParticleSystem fx = Instantiate(breakParticles, transform.position, Quaternion.identity);
            fx.Play();
            Destroy(fx.gameObject, 2f);
        }

        RuntimeFeedback.SpawnImpact(position, RuntimeFeedback.ImpactKind.Breakable);
        RuntimeFeedback.PlayGlassBreak();
        if (breakClip) AudioSource.PlayClipAtPoint(breakClip, transform.position);
        if (cachedCollider) cachedCollider.enabled = false;
        StartCoroutine(BreakRoutine());
    }

    System.Collections.IEnumerator BreakRoutine()
    {
        Vector3 startScale = transform.localScale;
        float t = 0f;
        while (t < 0.14f)
        {
            t += Time.deltaTime;
            float p = Mathf.Clamp01(t / 0.14f);
            float shrink = 1f - (p * 0.28f);
            transform.localScale = startScale * shrink;

            Color fade = new Color(0.74f, 0.96f, 1f, 1f - p);
            if (spriteRenderer) spriteRenderer.color = fade;
            if (meshRenderer && meshRenderer.material) meshRenderer.material.color = new Color(0.4f, 0.88f, 1f, 0.82f * (1f - p));
            if (runtimeSprite != null) runtimeSprite.SetTint(fade);
            yield return null;
        }

        if (spriteRenderer) spriteRenderer.enabled = false;
        if (meshRenderer) meshRenderer.enabled = false;
        Destroy(gameObject);
    }
}
