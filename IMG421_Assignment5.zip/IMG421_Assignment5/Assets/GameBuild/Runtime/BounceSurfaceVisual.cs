using UnityEngine;

public class BounceSurfaceVisual : MonoBehaviour
{
    private LatexBounceVisual latex;

    void Awake()
    {
        latex = GetComponent<LatexBounceVisual>();
        if (latex == null) latex = gameObject.AddComponent<LatexBounceVisual>();
    }
}
