using UnityEngine;

public class LatexBounceVisual : MonoBehaviour
{
    [SerializeField] private Color baseColor = new Color(1f, 0.04f, 0.58f, 1f);
    [SerializeField] private Color glowColor = new Color(1f, 0.56f, 0.86f, 1f);
    [SerializeField] private float pulseSpeed = 2.8f;
    [SerializeField] private float pulseAmount = 0.04f;

    private Renderer cachedRenderer;
    private Vector3 baseScale;
    private Transform shell;

    void Awake()
    {
        cachedRenderer = GetComponent<Renderer>();
        baseScale = transform.localScale;
        EnsureShell();
        ApplyBaseMaterial();
    }

    void Update()
    {
        float t = (Mathf.Sin(Time.time * pulseSpeed) + 1f) * 0.5f;
        Color c = Color.Lerp(baseColor, glowColor, t);

        if (cachedRenderer != null && cachedRenderer.material != null)
        {
            cachedRenderer.material.color = c;
            if (cachedRenderer.material.HasProperty("_EmissionColor"))
            {
                cachedRenderer.material.EnableKeyword("_EMISSION");
                cachedRenderer.material.SetColor("_EmissionColor", c * 0.12f);
            }
        }

        if (shell != null)
        {
            float squash = 1f + Mathf.Sin(Time.time * pulseSpeed) * pulseAmount;
            shell.localScale = new Vector3(squash, 1f / squash, 1.02f);
        }
    }

    private void ApplyBaseMaterial()
    {
        if (cachedRenderer == null || cachedRenderer.material == null) return;
        Material mat = cachedRenderer.material;
        mat.color = baseColor;
        if (mat.HasProperty("_Metallic")) mat.SetFloat("_Metallic", 0.02f);
        if (mat.HasProperty("_Glossiness")) mat.SetFloat("_Glossiness", 0.82f);
    }

    private void EnsureShell()
    {
        Transform existing = transform.Find("LatexShell");
        if (existing != null)
        {
            shell = existing;
            return;
        }

        shell = GameObject.CreatePrimitive(PrimitiveType.Cube).transform;
        shell.name = "LatexShell";
        shell.SetParent(transform, false);
        shell.localPosition = Vector3.zero;
        shell.localScale = new Vector3(1.02f, 1.02f, 1.02f);

        Collider col = shell.GetComponent<Collider>();
        if (col != null) Destroy(col);

        Renderer rend = shell.GetComponent<Renderer>();
        if (rend != null && rend.material != null)
        {
            rend.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            rend.receiveShadows = false;
            rend.material.color = new Color(1f, 0.56f, 0.86f, 0.34f);
            if (rend.material.HasProperty("_Metallic")) rend.material.SetFloat("_Metallic", 0f);
            if (rend.material.HasProperty("_Glossiness")) rend.material.SetFloat("_Glossiness", 0.95f);
        }
    }
}
