using UnityEngine;

public class SimpleImpactVFX : MonoBehaviour
{
    [SerializeField] private ParticleSystem wallImpactParticles;
    [SerializeField] private ParticleSystem bounceImpactParticles;
    [SerializeField] private AudioSource sfxSource;
    [SerializeField] private AudioClip wallHitClip;
    [SerializeField] private AudioClip bounceHitClip;

    private void OnCollisionEnter(Collision collision)
    {
        bool isBounceSurface = HasTag(collision.gameObject, "BounceSurface");
        Vector3 hitPoint = collision.contacts.Length > 0 ? collision.contacts[0].point : transform.position;

        if (isBounceSurface)
        {
            SpawnParticles(bounceImpactParticles, hitPoint);
            RuntimeFeedback.SpawnImpact(hitPoint, RuntimeFeedback.ImpactKind.Bounce);
            RuntimeFeedback.PlayBounceHit();
            PlayClip(bounceHitClip, hitPoint);
        }
        else
        {
            SpawnParticles(wallImpactParticles, hitPoint);
            RuntimeFeedback.SpawnImpact(hitPoint, RuntimeFeedback.ImpactKind.Solid);
            RuntimeFeedback.PlayWallHit();
            PlayClip(wallHitClip, hitPoint);
        }
    }

    private void SpawnParticles(ParticleSystem prefab, Vector3 position)
    {
        if (prefab == null) return;
        ParticleSystem fx = Instantiate(prefab, position, Quaternion.identity);
        fx.Play();
        Destroy(fx.gameObject, 2f);
    }

    private void PlayClip(AudioClip clip, Vector3 position)
    {
        if (clip == null) return;
        AudioSource.PlayClipAtPoint(clip, position);
    }

    private static bool HasTag(GameObject go, string tagName)
    {
        if (go == null) return false;
        try
        {
            return go.tag == tagName;
        }
        catch (UnityException)
        {
            return false;
        }
    }
}
