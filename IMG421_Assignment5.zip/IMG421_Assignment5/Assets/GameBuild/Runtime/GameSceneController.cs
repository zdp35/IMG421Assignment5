using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public enum DifficultyType { Easy, Medium, Hard }

public class GameSceneController : MonoBehaviour
{
    public static GameSceneController Instance { get; private set; }
    [SerializeField] private DifficultyType difficulty = DifficultyType.Easy;
    [SerializeField] private string mainMenuScene = "MainMenu";
    [SerializeField] private int maxAttempts = 5;
    [SerializeField] private float finishDelay = 0.5f;
    [SerializeField] private Text difficultyText;
    [SerializeField] private Text attemptsText;
    [SerializeField] private Text statusText;
    [SerializeField] private GameObject winPanel;
    [SerializeField] private GameObject losePanel;
    [SerializeField] private AudioSource musicSource;
    [SerializeField] private AudioSource sfxSource;
    [SerializeField] private AudioClip buttonClip;
    [SerializeField] private AudioClip winClip;
    [SerializeField] private AudioClip loseClip;

    public int AttemptsUsed { get; private set; }
    public bool LevelEnded { get; private set; }
    public int AttemptsRemaining => Mathf.Max(0, maxAttempts - AttemptsUsed);

    void Awake() { Instance = this; }

    void Start()
    {
        EnsureEventSystem();
        EnsureRuntimeUi();
        RuntimeFeedback.EnsureExists();
        if (GetComponent<RuntimePolishBootstrap>() == null) gameObject.AddComponent<RuntimePolishBootstrap>();
        AttemptsUsed = 0;
        LevelEnded = false;
        GoalZone.ResetGoal();
        ConfigureLevelVisuals();
        if (winPanel) winPanel.SetActive(false);
        if (losePanel) losePanel.SetActive(false);
        RefreshUI();
    }

    void Update()
    {
        if (!LevelEnded) return;
        if (Input.GetKeyDown(KeyCode.R)) RetryScene();
        if (Input.GetKeyDown(KeyCode.M) || Input.GetKeyDown(KeyCode.Escape)) ReturnToMainMenu();
    }

    public bool CanShoot() => !LevelEnded && AttemptsUsed < maxAttempts;

    public void RegisterShotFired()
    {
        if (LevelEnded) return;
        AttemptsUsed++;
        RefreshUI();
        if (AttemptsUsed >= maxAttempts)
        {
            StartCoroutine(CheckForLossAfterProjectileStops());
        }
    }

    IEnumerator CheckForLossAfterProjectileStops()
    {
        yield return new WaitForSeconds(0.5f);
        while (Projectile.AnyProjectileMoving()) yield return null;
        if (!GoalZone.goalMet && !LevelEnded) LoseLevel();
    }

    public void WinLevel()
    {
        if (LevelEnded) return;
        LevelEnded = true;
        if (difficultyText) difficultyText.text = difficulty + " Complete";
        if (statusText) statusText.text = "Nice shot. Press Retry or return to the main menu.";
        if (winClip && sfxSource) sfxSource.PlayOneShot(winClip);
        if (winPanel) winPanel.SetActive(true);
        RefreshUI();
    }

    public void LoseLevel()
    {
        if (LevelEnded) return;
        LevelEnded = true;
        if (difficultyText) difficultyText.text = difficulty + " Failed";
        if (statusText) statusText.text = "Out of attempts. Press Retry or return to the main menu.";
        if (loseClip && sfxSource) sfxSource.PlayOneShot(loseClip);
        if (losePanel) losePanel.SetActive(true);
        RefreshUI();
    }

    public void RetryScene()
    {
        PlayButton();
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    public void ReturnToMainMenu()
    {
        PlayButton();
        SceneManager.LoadScene(mainMenuScene);
    }

    private void RefreshUI()
    {
        if (difficultyText)
        {
            difficultyText.text = LevelEnded ? difficultyText.text : difficulty + " Mode";
        }

        if (attemptsText)
        {
            attemptsText.text = "Attempts Left: " + AttemptsRemaining + " / " + maxAttempts;
        }

        if (statusText)
        {
            statusText.gameObject.SetActive(false);
            if (statusText.transform.parent != null)
            {
                statusText.transform.parent.gameObject.SetActive(false);
            }
        }
    }

    private void ConfigureLevelVisuals()
    {
        ApplySolidWallVisuals();
        ApplyBreakableGlassVisuals();
        ApplyBounceWallVisuals();
    }

    private void ApplySolidWallVisuals()
    {
        Renderer[] renderers = FindObjectsOfType<Renderer>();
        foreach (Renderer renderer in renderers)
        {
            if (renderer == null) continue;
            GameObject go = renderer.gameObject;
            if (!IsSolidWall(go)) continue;

            BillboardSpriteVisual spriteVisual = go.GetComponent<BillboardSpriteVisual>();
            if (spriteVisual != null) Destroy(spriteVisual);
            Transform spriteChild = go.transform.Find("SpriteVisual");
            if (spriteChild != null) Destroy(spriteChild.gameObject);
            if (renderer != null) renderer.enabled = true;

            SolidWallDetailVisual detail = go.GetComponent<SolidWallDetailVisual>();
            if (detail == null) go.AddComponent<SolidWallDetailVisual>();

            Collider col = go.GetComponent<Collider>();
            if (col != null)
            {
                col.material = null;
            }
        }
    }

    private void ApplyBreakableGlassVisuals()
    {
        BreakableGlass[] glassPanels = FindObjectsOfType<BreakableGlass>();
        foreach (BreakableGlass glass in glassPanels)
        {
            if (glass == null) continue;

            Renderer renderer = glass.GetComponent<Renderer>();
            BillboardSpriteVisual spriteVisual = glass.GetComponent<BillboardSpriteVisual>();
            if (spriteVisual != null) Destroy(spriteVisual);
            Transform spriteChild = glass.transform.Find("SpriteVisual");
            if (spriteChild != null) Destroy(spriteChild.gameObject);
            if (renderer != null) renderer.enabled = true;

            FrostedGlassVisual visual = glass.GetComponent<FrostedGlassVisual>();
            if (visual == null) glass.gameObject.AddComponent<FrostedGlassVisual>();

            Collider col = glass.GetComponent<Collider>();
            if (col != null)
            {
                col.material = null;
            }
        }
    }

    private void ApplyBounceWallVisuals()
    {
        GameObject[] bounceObjects;
        try
        {
            bounceObjects = GameObject.FindGameObjectsWithTag("BounceSurface");
        }
        catch (UnityException)
        {
            return;
        }

        foreach (GameObject go in bounceObjects)
        {
            if (go == null) continue;

            BillboardSpriteVisual spriteVisual = go.GetComponent<BillboardSpriteVisual>();
            if (spriteVisual != null) Destroy(spriteVisual);
            Transform spriteChild = go.transform.Find("SpriteVisual");
            if (spriteChild != null) Destroy(spriteChild.gameObject);

            Renderer renderer = go.GetComponent<Renderer>();
            if (renderer != null) renderer.enabled = true;

            LatexBounceVisual pulse = go.GetComponent<LatexBounceVisual>();
            if (pulse == null)
            {
                pulse = go.AddComponent<LatexBounceVisual>();
            }

            Collider col = go.GetComponent<Collider>();
            if (col != null)
            {
                PhysicMaterial mat = new PhysicMaterial("RuntimeBounce")
                {
                    bounciness = 0.92f,
                    dynamicFriction = 0.02f,
                    staticFriction = 0.02f,
                    bounceCombine = PhysicMaterialCombine.Maximum,
                    frictionCombine = PhysicMaterialCombine.Minimum
                };
                col.material = mat;
            }
        }
    }

    private static bool IsSolidWall(GameObject go)
    {
        if (go == null) return false;
        if (HasTag(go, "BounceSurface")) return false;
        if (go.GetComponent<BreakableGlass>() != null) return false;
        if (go.GetComponent<GoalZone>() != null) return false;

        string name = go.name;
        return name.Contains("Wall") || name.Contains("Boundary");
    }


    private static bool HasTag(GameObject go, string tagName)
    {
        if (go == null) return false;
        try
        {
            return go.tag == tagName;
        }
        catch (UnityException)
        {
            return false;
        }
    }

    private void EnsureEventSystem()
    {
        if (FindObjectOfType<EventSystem>() != null) return;
        new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));
    }

    private void EnsureRuntimeUi()
    {
        Font font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        Canvas canvas = FindObjectOfType<Canvas>();
        if (canvas == null || canvas.name != "RuntimeHudCanvas")
        {
            canvas = new GameObject("RuntimeHudCanvas", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster)).GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            CanvasScaler scaler = canvas.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920, 1080);
        }

        if (!difficultyText)
        {
            difficultyText = CreateText(canvas.transform, "DifficultyText", font, 34, FontStyle.Bold, Color.white,
                TextAnchor.MiddleLeft, new Vector2(0.03f, 0.94f), new Vector2(500, 44));
        }

        if (!attemptsText)
        {
            attemptsText = CreateText(canvas.transform, "AttemptsText", font, 28, FontStyle.Bold, new Color(0.95f, 0.93f, 0.83f),
                TextAnchor.MiddleLeft, new Vector2(0.03f, 0.89f), new Vector2(420, 40));
        }

        if (statusText)
        {
            statusText.gameObject.SetActive(false);
            if (statusText.transform.parent != null)
            {
                statusText.transform.parent.gameObject.SetActive(false);
            }
        }

        if (!winPanel)
        {
            winPanel = CreateEndPanel(canvas.transform, font, "Level Complete", new Color(0.14f, 0.27f, 0.16f, 0.95f), new Color(0.63f, 0.93f, 0.55f));
            winPanel.name = "WinPanel";
            CreateEndPanelButtons(winPanel.transform, font);
        }

        if (!losePanel)
        {
            losePanel = CreateEndPanel(canvas.transform, font, "Defeat", new Color(0.28f, 0.10f, 0.12f, 0.95f), new Color(1f, 0.72f, 0.72f));
            losePanel.name = "LosePanel";
            CreateEndPanelButtons(losePanel.transform, font);
        }
    }

    private GameObject CreateEndPanel(Transform parent, Font font, string title, Color bg, Color titleColor)
    {
        GameObject panel = CreatePanel(parent, title.Replace(" ", "") + "Panel", bg, new Vector2(0.5f, 0.5f), new Vector2(720, 300));
        Text titleText = CreateText(panel.transform, "Title", font, 42, FontStyle.Bold, titleColor, TextAnchor.MiddleCenter, new Vector2(0.5f, 0.76f), new Vector2(620, 50));
        titleText.text = title;
        Text hintText = CreateText(panel.transform, "Hint", font, 24, FontStyle.Normal, Color.white, TextAnchor.MiddleCenter, new Vector2(0.5f, 0.58f), new Vector2(620, 40));
        hintText.text = "Retry this level or return to the main menu.";
        panel.SetActive(false);
        return panel;
    }

    private void CreateEndPanelButtons(Transform panel, Font font)
    {
        Button retry = CreateButton(panel, "RetryButton", font, "Retry Level", new Vector2(0.35f, 0.24f), new Vector2(220, 64),
            new Color(0.21f, 0.28f, 0.39f), new Color(0.28f, 0.36f, 0.49f), new Color(0.17f, 0.23f, 0.32f));
        retry.onClick.AddListener(RetryScene);

        Button menu = CreateButton(panel, "MenuButton", font, "Main Menu", new Vector2(0.65f, 0.24f), new Vector2(220, 64),
            new Color(0.28f, 0.24f, 0.18f), new Color(0.38f, 0.33f, 0.25f), new Color(0.21f, 0.18f, 0.13f));
        menu.onClick.AddListener(ReturnToMainMenu);
    }

    private GameObject CreatePanel(Transform parent, string name, Color color, Vector2 anchor, Vector2 size)
    {
        GameObject go = new GameObject(name, typeof(RectTransform), typeof(Image));
        go.transform.SetParent(parent, false);
        RectTransform rt = go.GetComponent<RectTransform>();
        rt.anchorMin = anchor;
        rt.anchorMax = anchor;
        rt.anchoredPosition = Vector2.zero;
        rt.sizeDelta = size;
        go.GetComponent<Image>().color = color;
        return go;
    }

    private Text CreateText(Transform parent, string name, Font font, int fontSize, FontStyle fontStyle, Color color, TextAnchor alignment, Vector2 anchor, Vector2 size)
    {
        GameObject go = new GameObject(name, typeof(RectTransform), typeof(Text));
        go.transform.SetParent(parent, false);
        RectTransform rt = go.GetComponent<RectTransform>();
        rt.anchorMin = anchor;
        rt.anchorMax = anchor;
        rt.anchoredPosition = Vector2.zero;
        rt.sizeDelta = size;
        Text text = go.GetComponent<Text>();
        text.font = font;
        text.fontSize = fontSize;
        text.fontStyle = fontStyle;
        text.color = color;
        text.alignment = alignment;
        text.horizontalOverflow = HorizontalWrapMode.Wrap;
        text.verticalOverflow = VerticalWrapMode.Overflow;
        return text;
    }

    private Button CreateButton(Transform parent, string name, Font font, string label, Vector2 anchor, Vector2 size, Color normal, Color highlighted, Color pressed)
    {
        GameObject go = new GameObject(name, typeof(RectTransform), typeof(Image), typeof(Button));
        go.transform.SetParent(parent, false);
        RectTransform rt = go.GetComponent<RectTransform>();
        rt.anchorMin = anchor;
        rt.anchorMax = anchor;
        rt.anchoredPosition = Vector2.zero;
        rt.sizeDelta = size;

        Image img = go.GetComponent<Image>();
        img.color = normal;
        Button button = go.GetComponent<Button>();
        ColorBlock colors = button.colors;
        colors.normalColor = normal;
        colors.highlightedColor = highlighted;
        colors.pressedColor = pressed;
        colors.selectedColor = highlighted;
        button.colors = colors;
        button.targetGraphic = img;

        Text txt = CreateText(go.transform, "Label", font, 24, FontStyle.Bold, Color.white, TextAnchor.MiddleCenter, new Vector2(0.5f, 0.5f), size);
        txt.text = label;
        return button;
    }

    private void PlayButton()
    {
        if (buttonClip && sfxSource) sfxSource.PlayOneShot(buttonClip);
    }
}
