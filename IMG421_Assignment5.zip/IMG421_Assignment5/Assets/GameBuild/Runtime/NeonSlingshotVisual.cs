using UnityEngine;

[RequireComponent(typeof(Slingshot))]
public class NeonSlingshotVisual : MonoBehaviour
{
    private static Sprite cachedSprite;

    private Slingshot slingshot;
    private Transform visualRoot;
    private Transform leftFork;
    private Transform rightFork;
    private Transform basePost;
    private LineRenderer leftBand;
    private LineRenderer rightBand;
    private Vector3 leftAnchorLocal;
    private Vector3 rightAnchorLocal;

    void Awake()
    {
        slingshot = GetComponent<Slingshot>();
        BuildVisual();
    }

    void LateUpdate()
    {
        if (slingshot == null) return;

        Vector3 target = slingshot.launchPos;
        if (slingshot.aimingMode && slingshot.projectile != null)
        {
            target = slingshot.projectile.transform.position;
        }

        if (leftBand != null)
        {
            leftBand.SetPosition(0, transform.TransformPoint(leftAnchorLocal));
            leftBand.SetPosition(1, target);
        }

        if (rightBand != null)
        {
            rightBand.SetPosition(0, transform.TransformPoint(rightAnchorLocal));
            rightBand.SetPosition(1, target);
        }
    }

    private void BuildVisual()
    {
        Transform old = transform.Find("NeonVisualRoot");
        if (old != null) Destroy(old.gameObject);

        visualRoot = new GameObject("NeonVisualRoot").transform;
        visualRoot.SetParent(transform, false);
        visualRoot.localPosition = Vector3.zero;
        visualRoot.localRotation = Quaternion.identity;

        CreateFrameSprites();
        CreateBands();
        DisableOldRenderer();
    }

    private void CreateFrameSprites()
    {
        leftFork = CreateBar("LeftFork", new Vector3(-0.42f, 0.78f, -0.05f), new Vector2(0.16f, 1.35f), -23f);
        rightFork = CreateBar("RightFork", new Vector3(0.42f, 0.78f, -0.05f), new Vector2(0.16f, 1.35f), 23f);
        basePost = CreateBar("BasePost", new Vector3(0f, 0.15f, -0.06f), new Vector2(0.28f, 1.8f), 0f);

        CreateGlow("LeftGlow", leftFork, new Vector2(0.26f, 1.55f));
        CreateGlow("RightGlow", rightFork, new Vector2(0.26f, 1.55f));
        CreateGlow("BaseGlow", basePost, new Vector2(0.42f, 2.0f));

        leftAnchorLocal = new Vector3(-0.33f, 1.24f, -0.03f);
        rightAnchorLocal = new Vector3(0.33f, 1.24f, -0.03f);

        CreateCap("LeftCap", leftAnchorLocal);
        CreateCap("RightCap", rightAnchorLocal);
    }

    private void CreateBands()
    {
        leftBand = CreateBand("LeftBand");
        rightBand = CreateBand("RightBand");
    }

    private Transform CreateBar(string name, Vector3 localPos, Vector2 size, float zRot)
    {
        GameObject go = new GameObject(name);
        go.transform.SetParent(visualRoot, false);
        go.transform.localPosition = localPos;
        go.transform.localRotation = Quaternion.Euler(0f, 0f, zRot);

        SpriteRenderer sr = go.AddComponent<SpriteRenderer>();
        sr.sprite = GetSprite();
        sr.color = new Color(0.05f, 0.95f, 0.7f, 0.95f);
        sr.sortingOrder = 20;
        go.transform.localScale = new Vector3(size.x, size.y, 1f);

        return go.transform;
    }

    private void CreateGlow(string name, Transform parent, Vector2 size)
    {
        GameObject glow = new GameObject(name);
        glow.transform.SetParent(parent, false);
        glow.transform.localPosition = new Vector3(0f, 0f, 0.02f);
        glow.transform.localRotation = Quaternion.identity;

        SpriteRenderer sr = glow.AddComponent<SpriteRenderer>();
        sr.sprite = GetSprite();
        sr.color = new Color(0.1f, 0.85f, 1f, 0.22f);
        sr.sortingOrder = 19;
        glow.transform.localScale = new Vector3(size.x, size.y, 1f);
    }

    private void CreateCap(string name, Vector3 localPos)
    {
        GameObject go = new GameObject(name);
        go.transform.SetParent(visualRoot, false);
        go.transform.localPosition = localPos + new Vector3(0f, 0f, -0.02f);
        go.transform.localRotation = Quaternion.identity;

        SpriteRenderer sr = go.AddComponent<SpriteRenderer>();
        sr.sprite = GetSprite();
        sr.color = new Color(0.6f, 1f, 1f, 0.95f);
        sr.sortingOrder = 21;
        go.transform.localScale = new Vector3(0.18f, 0.18f, 1f);
    }

    private LineRenderer CreateBand(string name)
    {
        GameObject go = new GameObject(name);
        go.transform.SetParent(visualRoot, false);
        LineRenderer lr = go.AddComponent<LineRenderer>();
        lr.positionCount = 2;
        lr.useWorldSpace = true;
        lr.material = new Material(Shader.Find("Sprites/Default"));
        lr.startColor = new Color(0.9f, 0.2f, 1f, 0.95f);
        lr.endColor = new Color(0.35f, 0.95f, 1f, 0.95f);
        lr.startWidth = 0.07f;
        lr.endWidth = 0.05f;
        lr.numCapVertices = 6;
        lr.sortingOrder = 22;
        return lr;
    }

    private void DisableOldRenderer()
    {
        Renderer[] renderers = GetComponents<Renderer>();
        foreach (Renderer renderer in renderers)
        {
            if (renderer is SpriteRenderer || renderer is LineRenderer) continue;
            renderer.enabled = false;
        }
    }

    private static Sprite GetSprite()
    {
        if (cachedSprite != null) return cachedSprite;

        Texture2D tex = new Texture2D(2, 2, TextureFormat.RGBA32, false);
        tex.SetPixels(new[]
        {
            Color.white, Color.white,
            Color.white, Color.white
        });
        tex.Apply();
        tex.name = "NeonSlingshotSprite";
        cachedSprite = Sprite.Create(tex, new Rect(0, 0, tex.width, tex.height), new Vector2(0.5f, 0.5f), 100f);
        return cachedSprite;
    }
}
