using UnityEngine;

public class RuntimePolishBootstrap : MonoBehaviour
{
    private bool applied;

    void Start()
    {
        if (applied) return;
        applied = true;
        RuntimeFeedback.EnsureExists();
        ApplySolidBackground();
        CreateNeonSlingshot();
    }

    private void ApplyEnvironmentSprites()
    {
        // Intentionally left empty so runtime polish does not replace level geometry.
    }

    private void ApplySolidBackground()
    {
        Camera cam = Camera.main;
        if (cam == null) cam = FindObjectOfType<Camera>();
        if (cam != null)
        {
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = new Color(0.05f, 0.08f, 0.16f, 1f);
        }

        GameObject oldBackdrop = GameObject.Find("RuntimeBackdrop");
        if (oldBackdrop != null) Destroy(oldBackdrop);
    }

    private Bounds CalculateLevelBounds()
    {
        Renderer[] renderers = FindObjectsOfType<Renderer>();
        bool hasBounds = false;
        Bounds bounds = new Bounds(Vector3.zero, Vector3.one * 10f);

        foreach (Renderer renderer in renderers)
        {
            if (renderer == null || !renderer.enabled) continue;
            if (renderer.GetComponentInParent<Canvas>() != null) continue;
            if (renderer.gameObject.name.Contains("RuntimeBackdrop")) continue;

            if (!hasBounds)
            {
                bounds = renderer.bounds;
                hasBounds = true;
            }
            else
            {
                bounds.Encapsulate(renderer.bounds);
            }
        }

        if (!hasBounds)
        {
            bounds = new Bounds(new Vector3(30f, 0f, 0f), new Vector3(60f, 30f, 10f));
        }

        return bounds;
    }

    private void CreateNeonSlingshot()
    {
        Slingshot slingshot = FindObjectOfType<Slingshot>();
        if (slingshot == null) return;

        BillboardSpriteVisual visual = slingshot.GetComponent<BillboardSpriteVisual>();
        if (visual != null) Destroy(visual);

        Transform spriteChild = slingshot.transform.Find("SpriteVisual");
        if (spriteChild != null) Destroy(spriteChild.gameObject);

        NeonSlingshotVisual neon = slingshot.GetComponent<NeonSlingshotVisual>();
        if (neon == null)
        {
            slingshot.gameObject.AddComponent<NeonSlingshotVisual>();
        }
    }

    private static bool IsSolidWall(GameObject go)
    {
        if (go == null) return false;
        if (HasTag(go, "BounceSurface")) return false;
        if (go.GetComponent<BreakableGlass>() != null) return false;
        if (go.GetComponent<GoalZone>() != null) return false;
        return go.name.Contains("Wall") || go.name.Contains("Boundary");
    }

    private static bool HasTag(GameObject go, string tagName)
    {
        if (go == null) return false;
        try { return go.tag == tagName; }
        catch (UnityException) { return false; }
    }
}
