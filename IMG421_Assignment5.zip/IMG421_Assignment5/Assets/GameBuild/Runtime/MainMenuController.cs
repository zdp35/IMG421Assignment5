using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class MainMenuController : MonoBehaviour
{
    [SerializeField] private string easyScene = "EasyScene";
    [SerializeField] private string mediumScene = "MediumScene";
    [SerializeField] private string hardScene = "HardScene";
    [SerializeField] private AudioSource sfxSource;
    [SerializeField] private AudioClip buttonClip;

    private Canvas runtimeCanvas;

    private void Start()
    {
        EnsureEventSystem();
        BuildMenuIfNeeded();
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Alpha1)) LoadEasy();
        if (Input.GetKeyDown(KeyCode.Alpha2)) LoadMedium();
        if (Input.GetKeyDown(KeyCode.Alpha3)) LoadHard();
        if (Input.GetKeyDown(KeyCode.Escape)) QuitGame();
    }

    public void LoadEasy() => LoadScene(easyScene);
    public void LoadMedium() => LoadScene(mediumScene);
    public void LoadHard() => LoadScene(hardScene);

    private void LoadScene(string sceneName)
    {
        PlayButton();
        SceneManager.LoadScene(sceneName);
    }

    public void QuitGame()
    {
        PlayButton();
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
    }

    private void PlayButton()
    {
        if (sfxSource != null && buttonClip != null)
        {
            sfxSource.PlayOneShot(buttonClip);
        }
    }

    private void EnsureEventSystem()
    {
        if (FindObjectOfType<EventSystem>() != null) return;
        GameObject es = new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));
        DontDestroyOnLoad(es);
    }

    private void BuildMenuIfNeeded()
    {
        if (FindObjectOfType<Canvas>() != null && GameObject.Find("RuntimeMainMenuCanvas") != null) return;

        runtimeCanvas = new GameObject("RuntimeMainMenuCanvas", typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster)).GetComponent<Canvas>();
        runtimeCanvas.renderMode = RenderMode.ScreenSpaceOverlay;
        CanvasScaler scaler = runtimeCanvas.GetComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920, 1080);

        Font font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");

        CreatePanel(runtimeCanvas.transform, "Backdrop", new Color(0.08f, 0.1f, 0.14f, 1f), new Vector2(0.5f, 0.5f), new Vector2(1920, 1080));
        CreateText(runtimeCanvas.transform, "Title", "Mission Demolition", font, 60, FontStyle.Bold,
            new Color(0.96f, 0.98f, 1f), TextAnchor.MiddleCenter, new Vector2(0.5f, 0.90f), new Vector2(1200, 90));
        CreateText(runtimeCanvas.transform, "Subtitle", "Choose a mode and start firing.", font, 24, FontStyle.Normal,
            new Color(0.82f, 0.89f, 0.98f), TextAnchor.MiddleCenter, new Vector2(0.5f, 0.84f), new Vector2(1000, 50));

        CreateDifficultyCard("EasyButton", "Easy", "Solid walls only. 5 shots. Straightforward maze path into a larger goal.",
            new Vector2(0.5f, 0.66f), new Color(0.26f, 0.29f, 0.33f), LoadEasy);
        CreateDifficultyCard("MediumButton", "Medium", "Solid and bounce walls. 4 shots. Use ricochets to hold your line.",
            new Vector2(0.5f, 0.44f), new Color(1f, 0.14f, 0.62f), LoadMedium);
        CreateDifficultyCard("HardButton", "Hard", "Solid, bounce, and glass walls. 3 shots. Break through and bank into the zone.",
            new Vector2(0.5f, 0.22f), new Color(0.24f, 0.82f, 1f), LoadHard);

        Button quit = CreateButton(runtimeCanvas.transform, "QuitButton", "Quit", font, new Vector2(0.89f, 0.08f), new Vector2(180, 58),
            new Color(0.17f, 0.20f, 0.26f), new Color(0.25f, 0.30f, 0.38f), new Color(0.13f, 0.16f, 0.21f));
        quit.onClick.AddListener(QuitGame);
    }

    private void CreateDifficultyCard(string name, string title, string description, Vector2 anchor, Color accent, UnityEngine.Events.UnityAction action)
    {
        Font font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        GameObject card = CreatePanel(runtimeCanvas.transform, name + "Card", new Color(0.11f, 0.14f, 0.19f, 0.98f), anchor, new Vector2(920, 168));
        Outline outline = card.AddComponent<Outline>();
        outline.effectColor = accent;
        outline.effectDistance = new Vector2(3f, -3f);

        Button button = card.AddComponent<Button>();
        ColorBlock colors = button.colors;
        colors.normalColor = new Color(1f,1f,1f,1f);
        colors.highlightedColor = new Color(1.05f,1.05f,1.05f,1f);
        colors.pressedColor = new Color(0.92f,0.92f,0.92f,1f);
        colors.selectedColor = colors.highlightedColor;
        button.colors = colors;
        button.targetGraphic = card.GetComponent<Image>();
        button.onClick.AddListener(action);

        CreatePanel(card.transform, "Accent", accent, new Vector2(0.04f, 0.5f), new Vector2(26, 124));
        CreateText(card.transform, "Title", title, font, 34, FontStyle.Bold, Color.white, TextAnchor.MiddleLeft, new Vector2(0.14f, 0.70f), new Vector2(240, 40));
        CreateText(card.transform, "Description", description, font, 21, FontStyle.Normal,
            new Color(0.84f, 0.9f, 0.97f), TextAnchor.MiddleCenter, new Vector2(0.48f, 0.42f), new Vector2(610, 72));
        CreateText(card.transform, "PlayHint", "Play", font, 24, FontStyle.Bold, accent, TextAnchor.MiddleCenter, new Vector2(0.88f, 0.5f), new Vector2(120, 36));
    }

    private GameObject CreatePanel(Transform parent, string name, Color color, Vector2 anchor, Vector2 size)
    {
        GameObject go = new GameObject(name, typeof(RectTransform), typeof(Image));
        go.transform.SetParent(parent, false);
        RectTransform rt = go.GetComponent<RectTransform>();
        rt.anchorMin = anchor;
        rt.anchorMax = anchor;
        rt.anchoredPosition = Vector2.zero;
        rt.sizeDelta = size;
        go.GetComponent<Image>().color = color;
        return go;
    }

    private Button CreateButton(Transform parent, string name, string label, Font font, Vector2 anchor, Vector2 size, Color normal, Color highlighted, Color pressed)
    {
        GameObject go = new GameObject(name, typeof(RectTransform), typeof(Image), typeof(Button));
        go.transform.SetParent(parent, false);
        RectTransform rt = go.GetComponent<RectTransform>();
        rt.anchorMin = anchor;
        rt.anchorMax = anchor;
        rt.anchoredPosition = Vector2.zero;
        rt.sizeDelta = size;

        Image image = go.GetComponent<Image>();
        image.color = normal;

        Button button = go.GetComponent<Button>();
        ColorBlock colors = button.colors;
        colors.normalColor = normal;
        colors.highlightedColor = highlighted;
        colors.pressedColor = pressed;
        colors.selectedColor = highlighted;
        button.colors = colors;
        button.targetGraphic = image;

        CreateText(go.transform, "Label", label, font, 24, FontStyle.Bold, Color.white, TextAnchor.MiddleCenter, new Vector2(0.5f, 0.5f), size);
        return button;
    }

    private void CreateText(Transform parent, string name, string content, Font font, int fontSize, FontStyle fontStyle,
        Color color, TextAnchor alignment, Vector2 anchor, Vector2 size)
    {
        GameObject go = new GameObject(name, typeof(RectTransform), typeof(Text));
        go.transform.SetParent(parent, false);
        RectTransform rt = go.GetComponent<RectTransform>();
        rt.anchorMin = anchor;
        rt.anchorMax = anchor;
        rt.anchoredPosition = Vector2.zero;
        rt.sizeDelta = size;

        Text text = go.GetComponent<Text>();
        text.font = font;
        text.text = content;
        text.fontSize = fontSize;
        text.fontStyle = fontStyle;
        text.color = color;
        text.alignment = alignment;
        text.horizontalOverflow = HorizontalWrapMode.Wrap;
        text.verticalOverflow = VerticalWrapMode.Overflow;
    }
}
