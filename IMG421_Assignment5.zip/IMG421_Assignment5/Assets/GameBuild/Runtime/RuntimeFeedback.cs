using UnityEngine;

public class RuntimeFeedback : MonoBehaviour
{
    private static RuntimeFeedback instance;
    private AudioSource sfxSource;
    private AudioSource musicSource;

    private AudioClip launchClip;
    private AudioClip wallHitClip;
    private AudioClip bounceHitClip;
    private AudioClip glassBreakClip;
    private AudioClip goalClip;
    private AudioClip musicLoop;

    public static void EnsureExists()
    {
        if (instance != null) return;
        GameObject go = new GameObject("RuntimeFeedback");
        instance = go.AddComponent<RuntimeFeedback>();
        DontDestroyOnLoad(go);
        instance.Initialize();
    }

    private void Initialize()
    {
        sfxSource = gameObject.AddComponent<AudioSource>();
        sfxSource.playOnAwake = false;
        sfxSource.spatialBlend = 0f;

        musicSource = gameObject.AddComponent<AudioSource>();
        musicSource.playOnAwake = false;
        musicSource.loop = true;
        musicSource.volume = 0.25f;
        musicSource.spatialBlend = 0f;

        launchClip = Resources.Load<AudioClip>("GameBuild/Audio/launch");
        wallHitClip = Resources.Load<AudioClip>("GameBuild/Audio/wall_hit");
        bounceHitClip = Resources.Load<AudioClip>("GameBuild/Audio/bounce_hit");
        glassBreakClip = Resources.Load<AudioClip>("GameBuild/Audio/glass_break");
        goalClip = Resources.Load<AudioClip>("GameBuild/Audio/goal");
        musicLoop = Resources.Load<AudioClip>("GameBuild/Audio/music_loop");

        if (musicLoop != null)
        {
            musicSource.clip = musicLoop;
            musicSource.Play();
        }
    }

    public static void PlayLaunch() => Play(instance != null ? instance.launchClip : null, 0.9f);
    public static void PlayWallHit() => Play(instance != null ? instance.wallHitClip : null, 0.75f);
    public static void PlayBounceHit() => Play(instance != null ? instance.bounceHitClip : null, 0.85f);
    public static void PlayGlassBreak() => Play(instance != null ? instance.glassBreakClip : null, 0.95f);
    public static void PlayGoal() => Play(instance != null ? instance.goalClip : null, 1f);

    public static void Play(AudioClip clip, float volume = 1f)
    {
        EnsureExists();
        if (instance == null || clip == null) return;
        instance.sfxSource.PlayOneShot(clip, volume);
    }

    public static void SpawnImpact(Vector3 position, ImpactKind kind)
    {
        EnsureExists();
        GameObject fxObject = new GameObject("ImpactFX_" + kind);
        fxObject.transform.position = position;
        ParticleSystem ps = fxObject.AddComponent<ParticleSystem>();
        ps.Stop(true, ParticleSystemStopBehavior.StopEmittingAndClear);

        var main = ps.main;
        main.loop = false;
        main.playOnAwake = false;
        main.duration = kind == ImpactKind.Breakable ? 0.8f : 0.35f;
        main.startLifetime = kind == ImpactKind.Breakable ? 0.85f : 0.28f;
        main.startSpeed = kind == ImpactKind.Bounce ? 3.8f : (kind == ImpactKind.Breakable ? 4.4f : 2.4f);
        main.startSize = kind == ImpactKind.Breakable ? 0.22f : 0.14f;
        main.simulationSpace = ParticleSystemSimulationSpace.World;
        main.maxParticles = kind == ImpactKind.Breakable ? 128 : 64;

        var emission = ps.emission;
        emission.rateOverTime = 0f;
        emission.SetBursts(new[] { new ParticleSystem.Burst(0f, (short)(kind == ImpactKind.Breakable ? 52 : 18)) });

        var shape = ps.shape;
        shape.enabled = true;
        shape.shapeType = kind == ImpactKind.Bounce ? ParticleSystemShapeType.Circle : ParticleSystemShapeType.Cone;
        shape.radius = kind == ImpactKind.Breakable ? 0.14f : 0.08f;
        shape.angle = kind == ImpactKind.Breakable ? 34f : 22f;

        var colorOverLifetime = ps.colorOverLifetime;
        colorOverLifetime.enabled = true;
        Gradient gradient = new Gradient();
        if (kind == ImpactKind.Bounce)
        {
            gradient.SetKeys(
                new[] { new GradientColorKey(new Color(1f, 0.45f, 0.75f), 0f), new GradientColorKey(new Color(1f, 0.82f, 0.92f), 1f) },
                new[] { new GradientAlphaKey(1f, 0f), new GradientAlphaKey(0f, 1f) });
        }
        else if (kind == ImpactKind.Breakable)
        {
            gradient.SetKeys(
                new[] { new GradientColorKey(new Color(0.18f, 0.78f, 1f), 0f), new GradientColorKey(new Color(0.78f, 0.95f, 1f), 0.55f), new GradientColorKey(new Color(1f, 1f, 1f), 1f) },
                new[] { new GradientAlphaKey(1f, 0f), new GradientAlphaKey(0.32f, 0.72f), new GradientAlphaKey(0f, 1f) });
        }
        else
        {
            gradient.SetKeys(
                new[] { new GradientColorKey(new Color(0.76f, 0.78f, 0.82f), 0f), new GradientColorKey(new Color(0.48f, 0.5f, 0.56f), 1f) },
                new[] { new GradientAlphaKey(0.9f, 0f), new GradientAlphaKey(0f, 1f) });
        }
        colorOverLifetime.color = new ParticleSystem.MinMaxGradient(gradient);

        var sizeOverLifetime = ps.sizeOverLifetime;
        sizeOverLifetime.enabled = true;
        AnimationCurve curve = new AnimationCurve();
        curve.AddKey(0f, 1f);
        curve.AddKey(1f, 0f);
        sizeOverLifetime.size = new ParticleSystem.MinMaxCurve(1f, curve);

        if (kind == ImpactKind.Breakable)
        {
            var force = ps.forceOverLifetime;
            force.enabled = true;
            force.y = -1.65f;

            var noise = ps.noise;
            noise.enabled = true;
            noise.strength = 0.45f;
            noise.frequency = 0.75f;

            var trails = ps.trails;
            trails.enabled = true;
            trails.mode = ParticleSystemTrailMode.PerParticle;
            trails.lifetime = 0.2f;
            trails.dieWithParticles = true;
            trails.inheritParticleColor = true;
        }

        ps.Play();
        Destroy(fxObject, kind == ImpactKind.Breakable ? 2.2f : 1.5f);
    }

    public enum ImpactKind
    {
        Solid,
        Bounce,
        Breakable
    }
}
