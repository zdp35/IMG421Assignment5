#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

[InitializeOnLoad]
public static class AssignmentSceneBuilder
{
    private const string SceneFolder = "Assets/Scenes";
    private const string RuntimeFolder = "Assets/GameBuild/Runtime";
    private const string ArtFolder = "Assets/GameBuild/Art";
    private const string AudioFolder = "Assets/GameBuild/Audio";
    private const string GeneratedFolder = "Assets/GameBuild/Generated";

    static AssignmentSceneBuilder()
    {
        EditorApplication.delayCall += AutoBuildIfNeeded;
    }

    [MenuItem("Tools/Mission Demolition/Rebuild Assignment Scenes")]
    public static void ForceRebuild()
    {
        BuildAll(true);
    }

    private static void AutoBuildIfNeeded()
    {
        if (Application.isPlaying) return;
        if (File.Exists(Path.Combine(SceneFolder, "MainMenu.unity")) &&
            File.Exists(Path.Combine(SceneFolder, "EasyScene.unity")) &&
            File.Exists(Path.Combine(SceneFolder, "MediumScene.unity")) &&
            File.Exists(Path.Combine(SceneFolder, "HardScene.unity")))
        {
            return;
        }

        BuildAll(false);
    }

    private static void BuildAll(bool force)
    {
        EnsureFolder(SceneFolder);
        EnsureFolder(GeneratedFolder);
        EnsureFolder(GeneratedFolder + "/Prefabs");
        EnsureFolder(GeneratedFolder + "/Physics");

        AddTagIfMissing("BounceSurface");
        AddTagIfMissing("GoalZone");

        ConfigureTextureImports();
        AssetDatabase.Refresh();

        PhysicMaterial bounceMat = GetOrCreateBounceMaterial();
        ParticleSystem wallFx = GetOrCreateImpactPrefab("WallImpact", new Color(0.8f, 0.85f, 0.9f), 20, 0.3f);
        ParticleSystem bounceFx = GetOrCreateImpactPrefab("BounceImpact", new Color(0.45f, 0.95f, 1f), 28, 0.45f);
        ParticleSystem goalFx = GetOrCreateImpactPrefab("GoalBurst", new Color(0.95f, 0.95f, 0.35f), 36, 0.6f);
        ParticleSystem glassFx = GetOrCreateImpactPrefab("GlassBurst", new Color(0.8f, 0.95f, 1f), 42, 0.5f);

        GameObject projectilePrefab = GetOrCreateProjectilePrefab(wallFx, bounceFx);

        BuildMenuScene(force);
        BuildGameplayScene("EasyScene", DifficultyType.Easy, 5, bounceMat, projectilePrefab, wallFx, bounceFx, goalFx, glassFx, force);
        BuildGameplayScene("MediumScene", DifficultyType.Medium, 4, bounceMat, projectilePrefab, wallFx, bounceFx, goalFx, glassFx, force);
        BuildGameplayScene("HardScene", DifficultyType.Hard, 3, bounceMat, projectilePrefab, wallFx, bounceFx, goalFx, glassFx, force);

        EditorBuildSettings.scenes = new[]
        {
            new EditorBuildSettingsScene(SceneFolder + "/MainMenu.unity", true),
            new EditorBuildSettingsScene(SceneFolder + "/EasyScene.unity", true),
            new EditorBuildSettingsScene(SceneFolder + "/MediumScene.unity", true),
            new EditorBuildSettingsScene(SceneFolder + "/HardScene.unity", true),
        };
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        Debug.Log("Mission Demolition assignment scenes generated.");
    }

    private static void BuildMenuScene(bool force)
    {
        string scenePath = SceneFolder + "/MainMenu.unity";
        if (!force && File.Exists(scenePath)) return;

        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        scene.name = "MainMenu";

        CreateCamera(new Vector3(0, 0, -10f), 18f, false);
        CreateEventSystem();

        Canvas canvas = CreateCanvas("Canvas");
        CreateFullScreenImage(canvas.transform, "MenuBg", new Color(0.08f, 0.11f, 0.16f, 1f));
        CreateText(canvas.transform, "TitleText", "Mission Demolition: Precision Trials", 42, TextAnchor.MiddleCenter,
            new Vector2(0.5f, 0.82f), new Vector2(700, 80), Color.white);
        CreateText(canvas.transform, "SubtitleText", "Choose a difficulty. Each mode has limited shots and a unique mechanic.", 22, TextAnchor.MiddleCenter,
            new Vector2(0.5f, 0.72f), new Vector2(860, 50), new Color(0.85f, 0.9f, 0.97f));

        GameObject controllerGo = new GameObject("MainMenuController");
        MainMenuController controller = controllerGo.AddComponent<MainMenuController>();
        AudioSource sfx = controllerGo.AddComponent<AudioSource>();
        sfx.playOnAwake = false;
        controllerGo.AddComponent<AudioListener>();
        SetPrivateField(controller, "sfxSource", sfx);
        SetPrivateField(controller, "buttonClip", LoadAudio("button.wav"));

        GameObject musicGo = new GameObject("Music");
        AudioSource music = musicGo.AddComponent<AudioSource>();
        music.clip = LoadAudio("music_loop.wav");
        music.loop = true;
        music.playOnAwake = true;

        CreateMenuButton(canvas.transform, "EasyButton", "Easy - Maze Shot", new Vector2(0.5f, 0.56f));
        CreateMenuButton(canvas.transform, "MediumButton", "Medium - Ricochet Run", new Vector2(0.5f, 0.44f));
        CreateMenuButton(canvas.transform, "HardButton", "Hard - Glass Breaker", new Vector2(0.5f, 0.32f));
        CreateMenuButton(canvas.transform, "QuitButton", "Quit", new Vector2(0.5f, 0.18f), new Vector2(240, 60));

        EditorSceneManager.SaveScene(scene, scenePath);
    }

    private static void BuildGameplayScene(string sceneName, DifficultyType difficulty, int attempts, PhysicMaterial bounceMat,
        GameObject projectilePrefab, ParticleSystem wallFx, ParticleSystem bounceFx, ParticleSystem goalFx, ParticleSystem glassFx, bool force)
    {
        string scenePath = SceneFolder + "/" + sceneName + ".unity";
        if (!force && File.Exists(scenePath)) return;

        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        scene.name = sceneName;

        CreateDirectionalLight();
        Camera cam = CreateCamera(new Vector3(10f, 8f, -30f), 11f, true);
        GameObject viewBoth = new GameObject("ViewBoth");
        viewBoth.transform.position = new Vector3(14f, 7f, 0f);
        FollowCam follow = cam.gameObject.AddComponent<FollowCam>();
        follow.easing = 0.08f;
        follow.minXY = Vector2.zero;
        follow.viewBothGO = viewBoth;

        CreateEventSystem();
        // Background sprite intentionally omitted; camera uses a solid color.
        CreateGround();

        Canvas canvas = CreateCanvas("Canvas");
        CreateHud(canvas.transform);
        CreateEndPanels(canvas.transform);

        GameObject controllerGo = new GameObject("GameController");
        GameSceneController controller = controllerGo.AddComponent<GameSceneController>();
        AudioSource music = controllerGo.AddComponent<AudioSource>();
        music.clip = LoadAudio("music_loop.wav");
        music.loop = true;
        music.playOnAwake = true;
        AudioSource sfx = controllerGo.AddComponent<AudioSource>();
        sfx.playOnAwake = false;
        SetPrivateField(controller, "difficulty", difficulty);
        SetPrivateField(controller, "maxAttempts", attempts);
        SetPrivateField(controller, "musicSource", music);
        SetPrivateField(controller, "sfxSource", sfx);
        SetPrivateField(controller, "buttonClip", LoadAudio("button.wav"));
        SetPrivateField(controller, "winClip", LoadAudio("win.wav"));
        SetPrivateField(controller, "loseClip", LoadAudio("lose.wav"));

        GameObject slingshot = CreateSlingshot(projectilePrefab);
        slingshot.transform.position = new Vector3(2.5f, 1.6f, 0f);

        if (difficulty == DifficultyType.Easy)
            CreateGoal(goalFx, new Vector3(18f, 2.6f, 0f), new Vector2(4.8f, 3.2f));
        else if (difficulty == DifficultyType.Medium)
            CreateGoal(goalFx, new Vector3(19.5f, 3.2f, 0f), new Vector2(4.2f, 3.0f));
        else
            CreateGoal(goalFx, new Vector3(20.5f, 2.8f, 0f), new Vector2(3.8f, 2.8f));

        BuildLevelGeometry(difficulty, bounceMat, glassFx);

        EditorSceneManager.SaveScene(scene, scenePath);
    }

    private static void BuildLevelGeometry(DifficultyType difficulty, PhysicMaterial bounceMat, ParticleSystem glassFx)
    {
        // Maze frame
        CreateWall("LeftBoundary", new Vector3(0f, 6f, 0f), new Vector2(0.5f, 12f), false, null);
        CreateWall("RightBoundary", new Vector3(27f, 6f, 0f), new Vector2(0.5f, 12f), false, null);
        CreateWall("TopBoundary", new Vector3(13.5f, 12f, 0f), new Vector2(27f, 0.5f), false, null);
        CreateWall("BottomBoundary", new Vector3(13.5f, 0f, 0f), new Vector2(27f, 0.5f), false, null);

        if (difficulty == DifficultyType.Easy)
        {
            CreateWall("EasyWall1", new Vector3(8f, 4f, 0f), new Vector2(0.6f, 6f), false, null);
            CreateWall("EasyWall2", new Vector3(12f, 8.8f, 0f), new Vector2(8f, 0.6f), false, null);
            CreateWall("EasyWall3", new Vector3(16f, 4.1f, 0f), new Vector2(0.6f, 6.2f), false, null);
            CreateWall("EasyWall4", new Vector3(20.1f, 8.2f, 0f), new Vector2(6f, 0.6f), false, null);
            CreateWall("EasyWall5", new Vector3(22.5f, 4.6f, 0f), new Vector2(0.6f, 5f), false, null);
        }
        else if (difficulty == DifficultyType.Medium)
        {
            CreateWall("MedWall1", new Vector3(7.5f, 4.5f, 0f), new Vector2(0.6f, 7f), false, null);
            CreateWall("MedWall2", new Vector3(11.5f, 9f, 0f), new Vector2(8f, 0.6f), false, null);
            CreateWall("MedBounce1", new Vector3(14.5f, 4f, 0f), new Vector2(0.6f, 6.5f), true, bounceMat);
            CreateWall("MedWall3", new Vector3(18.5f, 2.4f, 0f), new Vector2(8f, 0.6f), false, null);
            CreateWall("MedBounce2", new Vector3(21.8f, 7.2f, 0f), new Vector2(0.6f, 7.6f), true, bounceMat);
            CreateWall("MedWall4", new Vector3(24f, 10.1f, 0f), new Vector2(5f, 0.6f), false, null);
        }
        else
        {
            CreateWall("HardWall1", new Vector3(7f, 4.2f, 0f), new Vector2(0.6f, 7.2f), false, null);
            CreateWall("HardBounce1", new Vector3(11f, 9.2f, 0f), new Vector2(7f, 0.6f), true, bounceMat);
            CreateGlass("Glass1", new Vector3(14.6f, 5.6f, 0f), new Vector2(0.7f, 4.8f), glassFx);
            CreateWall("HardWall2", new Vector3(17.8f, 2.2f, 0f), new Vector2(7.4f, 0.6f), false, null);
            CreateWall("HardBounce2", new Vector3(20.5f, 7.5f, 0f), new Vector2(0.6f, 7f), true, bounceMat);
            CreateGlass("Glass2", new Vector3(23.5f, 9.6f, 0f), new Vector2(4f, 0.7f), glassFx);
            CreateWall("HardWall3", new Vector3(24.8f, 4.3f, 0f), new Vector2(0.6f, 5.5f), false, null);
        }
    }

    private static void CreateBackground()
    {
        Sprite bgSprite = LoadSprite("background.png");
        GameObject go = new GameObject("Background");
        SpriteRenderer sr = go.AddComponent<SpriteRenderer>();
        sr.sprite = bgSprite;
        sr.sortingOrder = -10;
        go.transform.position = new Vector3(13.5f, 6f, 5f);
        Vector2 bgSize = sr.sprite != null ? sr.sprite.bounds.size : Vector2.one;
        go.transform.localScale = new Vector3(54f / bgSize.x, 24f / bgSize.y, 1f);
    }

    private static void CreateGround()
    {
        GameObject ground = GameObject.CreatePrimitive(PrimitiveType.Cube);
        ground.name = "Ground";
        ground.transform.position = new Vector3(13.5f, -0.75f, 0f);
        ground.transform.localScale = new Vector3(28f, 1.5f, 1f);
        Renderer r = ground.GetComponent<Renderer>();
        r.sharedMaterial = new Material(Shader.Find("Standard"));
        r.sharedMaterial.color = new Color(0.25f, 0.3f, 0.36f);
    }

    private static GameObject CreateSlingshot(GameObject projectilePrefab)
    {
        GameObject root = new GameObject("Slingshot");
        SphereCollider collider = root.AddComponent<SphereCollider>();
        collider.radius = 1.5f;
        collider.center = new Vector3(0f, 1.8f, 0f);
        Slingshot sling = root.AddComponent<Slingshot>();
        sling.projectilePrefab = projectilePrefab;
        sling.velocityMult = 9.1f;
        sling.launchClip = LoadAudio("launch.wav");

        CreateSpritePanel(root.transform, "Base", LoadSprite("wood.png"), new Vector3(0f, 0.8f, 0f), new Vector2(0.8f, 1.6f), null, false);
        CreateSpritePanel(root.transform, "LeftArm", LoadSprite("wood.png"), new Vector3(-0.38f, 2.25f, 0f), new Vector2(0.45f, 2.6f), null, false, 20f);
        CreateSpritePanel(root.transform, "RightArm", LoadSprite("wood.png"), new Vector3(0.38f, 2.25f, 0f), new Vector2(0.45f, 2.6f), null, false, -20f);

        GameObject launchPoint = new GameObject("LaunchPoint");
        launchPoint.transform.SetParent(root.transform);
        launchPoint.transform.localPosition = new Vector3(0f, 3.5f, 0f);

        return root;
    }

    private static GameObject CreateGoal(ParticleSystem goalFx, Vector3 position, Vector2 size)
    {
        GameObject goal = CreateSpritePanel(null, "GoalZone", LoadSprite("goal.png"), position, size, null, true);
        goal.tag = "GoalZone";
        BoxCollider bc = goal.GetComponent<BoxCollider>();
        bc.isTrigger = true;
        bc.size = new Vector3(0.95f, 0.95f, 1f);
        GoalZone zone = goal.AddComponent<GoalZone>();
        SetPrivateField(zone, "spriteRenderer", goal.GetComponent<SpriteRenderer>());
        SetPrivateField(zone, "successParticles", Object.Instantiate(goalFx));
        SetPrivateField(zone, "sfxSource", goal.AddComponent<AudioSource>());
        SetPrivateField(zone, "successClip", LoadAudio("goal.wav"));
        goal.AddComponent<PulseVisual>();
        return goal;
    }

    private static GameObject CreateWall(string name, Vector3 position, Vector2 size, bool bounce, PhysicMaterial bounceMat)
    {
        GameObject wall = CreateSpritePanel(null, name, LoadSprite(bounce ? "bounce.png" : "wall.png"), position, size, bounce ? bounceMat : null, true);
        if (bounce)
        {
            wall.tag = "BounceSurface";
            wall.AddComponent<BounceSurfaceVisual>();
        }
        return wall;
    }

    private static GameObject CreateGlass(string name, Vector3 position, Vector2 size, ParticleSystem glassFx)
    {
        GameObject glass = CreateSpritePanel(null, name, LoadSprite("glass_intact.png"), position, size, null, true);
        BreakableGlass breakable = glass.AddComponent<BreakableGlass>();
        SetPrivateField(breakable, "spriteRenderer", glass.GetComponent<SpriteRenderer>());
        SetPrivateField(breakable, "intactSprite", LoadSprite("glass_intact.png"));
        SetPrivateField(breakable, "crackedSprite", LoadSprite("glass_cracked.png"));
        SetPrivateField(breakable, "breakParticles", Object.Instantiate(glassFx));
        SetPrivateField(breakable, "breakClip", LoadAudio("glass_break.wav"));
        return glass;
    }

    private static GameObject CreateSpritePanel(Transform parent, string name, Sprite sprite, Vector3 localPosition, Vector2 size, PhysicMaterial material, bool addCollider, float zRotation = 0f)
    {
        GameObject go = new GameObject(name);
        if (parent != null) go.transform.SetParent(parent);
        go.transform.localPosition = localPosition;
        go.transform.localRotation = Quaternion.Euler(0f, 0f, zRotation);
        SpriteRenderer sr = go.AddComponent<SpriteRenderer>();
        sr.sprite = sprite;
        Vector2 spriteSize = sr.sprite != null ? sr.sprite.bounds.size : Vector2.one;
        go.transform.localScale = new Vector3(size.x / spriteSize.x, size.y / spriteSize.y, 1f);
        if (addCollider)
        {
            BoxCollider bc = go.AddComponent<BoxCollider>();
            bc.size = new Vector3(1f, 1f, 0.5f);
            bc.material = material;
        }
        return go;
    }

    private static GameObject GetOrCreateProjectilePrefab(ParticleSystem wallFx, ParticleSystem bounceFx)
    {
        string path = GeneratedFolder + "/Prefabs/Projectile.prefab";
        GameObject prefab = AssetDatabase.LoadAssetAtPath<GameObject>(path);
        if (prefab != null) return prefab;

        GameObject go = new GameObject("Projectile");
        SpriteRenderer sr = go.AddComponent<SpriteRenderer>();
        sr.sprite = LoadSprite("projectile.png");
        sr.sortingOrder = 10;
        SphereCollider sc = go.AddComponent<SphereCollider>();
        sc.radius = 0.45f;
        Rigidbody rb = go.AddComponent<Rigidbody>();
        rb.useGravity = true;
        rb.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
        rb.interpolation = RigidbodyInterpolation.Interpolate;
        Projectile projectile = go.AddComponent<Projectile>();
        SimpleImpactVFX impact = go.AddComponent<SimpleImpactVFX>();
        SetPrivateField(impact, "wallImpactParticles", wallFx);
        SetPrivateField(impact, "bounceImpactParticles", bounceFx);
        SetPrivateField(impact, "wallHitClip", LoadAudio("wall_hit.wav"));
        SetPrivateField(impact, "bounceHitClip", LoadAudio("bounce_hit.wav"));
        Vector2 spriteSize = sr.sprite != null ? sr.sprite.bounds.size : Vector2.one;
        go.transform.localScale = new Vector3(0.9f / spriteSize.x, 0.9f / spriteSize.y, 1f);

        prefab = PrefabUtility.SaveAsPrefabAsset(go, path);
        Object.DestroyImmediate(go);
        AssetDatabase.SaveAssets();
        return prefab;
    }

    private static ParticleSystem GetOrCreateImpactPrefab(string name, Color color, int burstCount, float size)
    {
        string path = GeneratedFolder + "/Prefabs/" + name + ".prefab";
        ParticleSystem prefab = AssetDatabase.LoadAssetAtPath<ParticleSystem>(path);
        if (prefab != null) return prefab;

        GameObject go = new GameObject(name);
        ParticleSystem ps = go.AddComponent<ParticleSystem>();
        var main = ps.main;
        main.loop = false;
        main.playOnAwake = false;
        main.duration = 0.45f;
        main.startLifetime = new ParticleSystem.MinMaxCurve(0.25f, 0.45f);
        main.startSpeed = new ParticleSystem.MinMaxCurve(1.5f, 4.5f);
        main.startSize = new ParticleSystem.MinMaxCurve(size * 0.5f, size);
        main.startColor = color;
        main.simulationSpace = ParticleSystemSimulationSpace.World;
        var emission = ps.emission;
        emission.rateOverTime = 0f;
        emission.SetBursts(new[] { new ParticleSystem.Burst(0f, (short)burstCount) });
        var shape = ps.shape;
        shape.shapeType = ParticleSystemShapeType.Circle;
        shape.radius = 0.1f;
        var colorOverLifetime = ps.colorOverLifetime;
        colorOverLifetime.enabled = true;
        Gradient grad = new Gradient();
        grad.SetKeys(
            new[] { new GradientColorKey(color, 0f), new GradientColorKey(color, 1f) },
            new[] { new GradientAlphaKey(1f, 0f), new GradientAlphaKey(0f, 1f) });
        colorOverLifetime.color = grad;
        var renderer = ps.GetComponent<ParticleSystemRenderer>();
        renderer.material = new Material(Shader.Find("Sprites/Default"));
        prefab = PrefabUtility.SaveAsPrefabAsset(go, path).GetComponent<ParticleSystem>();
        Object.DestroyImmediate(go);
        AssetDatabase.SaveAssets();
        return prefab;
    }

    private static PhysicMaterial GetOrCreateBounceMaterial()
    {
        string path = GeneratedFolder + "/Physics/Bounce.physicMaterial";
        PhysicMaterial mat = AssetDatabase.LoadAssetAtPath<PhysicMaterial>(path);
        if (mat != null) return mat;
        mat = new PhysicMaterial("Bounce")
        {
            bounciness = 1f,
            dynamicFriction = 0f,
            staticFriction = 0f,
            bounceCombine = PhysicMaterialCombine.Maximum,
            frictionCombine = PhysicMaterialCombine.Minimum
        };
        AssetDatabase.CreateAsset(mat, path);
        AssetDatabase.SaveAssets();
        return mat;
    }

    private static Sprite LoadSprite(string fileName)
    {
        return AssetDatabase.LoadAssetAtPath<Sprite>(ArtFolder + "/" + fileName);
    }

    private static AudioClip LoadAudio(string fileName)
    {
        return AssetDatabase.LoadAssetAtPath<AudioClip>(AudioFolder + "/" + fileName);
    }

    private static void ConfigureTextureImports()
    {
        string[] files = Directory.GetFiles(ArtFolder, "*.png");
        foreach (string fullPath in files)
        {
            string assetPath = fullPath.Replace('\\', '/');
            TextureImporter importer = AssetImporter.GetAtPath(assetPath) as TextureImporter;
            if (importer == null) continue;
            importer.textureType = TextureImporterType.Sprite;
            importer.spriteImportMode = SpriteImportMode.Single;
            importer.alphaIsTransparency = true;
            importer.mipmapEnabled = false;
            importer.filterMode = FilterMode.Bilinear;
            importer.SaveAndReimport();
        }
    }

    private static Camera CreateCamera(Vector3 position, float orthoSize, bool addListener)
    {
        GameObject go = new GameObject("Main Camera");
        go.tag = "MainCamera";
        Camera cam = go.AddComponent<Camera>();
        cam.orthographic = true;
        cam.orthographicSize = orthoSize;
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.backgroundColor = new Color(0.05f, 0.08f, 0.16f);
        go.transform.position = position;
        if (addListener) go.AddComponent<AudioListener>();
        return cam;
    }

    private static void CreateDirectionalLight()
    {
        GameObject lightGo = new GameObject("Directional Light");
        Light light = lightGo.AddComponent<Light>();
        light.type = LightType.Directional;
        light.intensity = 1.1f;
        lightGo.transform.rotation = Quaternion.Euler(50f, -30f, 0f);
    }

    private static Canvas CreateCanvas(string name)
    {
        GameObject go = new GameObject(name);
        Canvas canvas = go.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        go.AddComponent<CanvasScaler>().uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        go.AddComponent<GraphicRaycaster>();
        return canvas;
    }

    private static void CreateEventSystem()
    {
        GameObject es = new GameObject("EventSystem");
        es.AddComponent<EventSystem>();
        es.AddComponent<StandaloneInputModule>();
    }

    private static void CreateHud(Transform parent)
    {
        CreateText(parent, "DifficultyText", "Mode: Easy", 24, TextAnchor.UpperLeft, new Vector2(0f, 1f), new Vector2(280, 36), Color.white, new Vector2(12, -10));
        CreateText(parent, "AttemptsText", "Attempts: 5/5", 24, TextAnchor.UpperLeft, new Vector2(0f, 1f), new Vector2(280, 36), Color.white, new Vector2(12, -48));
        CreateText(parent, "StatusText", "Land the projectile in the zone", 22, TextAnchor.UpperLeft, new Vector2(0f, 1f), new Vector2(540, 36), new Color(0.9f, 0.95f, 1f), new Vector2(12, -86));
    }

    private static void CreateEndPanels(Transform parent)
    {
        GameObject win = CreatePanel(parent, "WinPanel", new Color(0.08f, 0.14f, 0.1f, 0.88f));
        CreateText(win.transform, "WinText", "You Win", 34, TextAnchor.MiddleCenter, new Vector2(0.5f, 0.72f), new Vector2(260, 50), Color.white);
        CreateMenuButton(win.transform, "WinRetryButton", "Retry", new Vector2(0.5f, 0.46f), new Vector2(220, 55));
        CreateMenuButton(win.transform, "WinMenuButton", "Main Menu", new Vector2(0.5f, 0.28f), new Vector2(220, 55));
        win.SetActive(false);

        GameObject lose = CreatePanel(parent, "LosePanel", new Color(0.16f, 0.08f, 0.08f, 0.88f));
        CreateText(lose.transform, "LoseText", "Out of Attempts", 34, TextAnchor.MiddleCenter, new Vector2(0.5f, 0.72f), new Vector2(360, 50), Color.white);
        CreateMenuButton(lose.transform, "LoseRetryButton", "Retry", new Vector2(0.5f, 0.46f), new Vector2(220, 55));
        CreateMenuButton(lose.transform, "LoseMenuButton", "Main Menu", new Vector2(0.5f, 0.28f), new Vector2(220, 55));
        lose.SetActive(false);
    }

    private static GameObject CreatePanel(Transform parent, string name, Color color)
    {
        GameObject go = new GameObject(name);
        go.transform.SetParent(parent, false);
        Image image = go.AddComponent<Image>();
        image.color = color;
        RectTransform rt = go.GetComponent<RectTransform>();
        rt.anchorMin = new Vector2(0.5f, 0.5f);
        rt.anchorMax = new Vector2(0.5f, 0.5f);
        rt.sizeDelta = new Vector2(420, 260);
        rt.anchoredPosition = Vector2.zero;
        return go;
    }

    private static GameObject CreateFullScreenImage(Transform parent, string name, Color color)
    {
        GameObject go = new GameObject(name);
        go.transform.SetParent(parent, false);
        Image img = go.AddComponent<Image>();
        img.color = color;
        RectTransform rt = img.rectTransform;
        rt.anchorMin = Vector2.zero;
        rt.anchorMax = Vector2.one;
        rt.offsetMin = Vector2.zero;
        rt.offsetMax = Vector2.zero;
        return go;
    }

    private static GameObject CreateMenuButton(Transform parent, string name, string label, Vector2 anchor, Vector2? sizeOverride = null)
    {
        GameObject go = new GameObject(name);
        go.transform.SetParent(parent, false);
        Image img = go.AddComponent<Image>();
        img.color = new Color(0.18f, 0.33f, 0.58f, 0.95f);
        Button button = go.AddComponent<Button>();
        ColorBlock cb = button.colors;
        cb.normalColor = img.color;
        cb.highlightedColor = new Color(0.28f, 0.48f, 0.8f, 1f);
        cb.pressedColor = new Color(0.12f, 0.24f, 0.42f, 1f);
        button.colors = cb;
        RectTransform rt = go.GetComponent<RectTransform>();
        rt.anchorMin = anchor;
        rt.anchorMax = anchor;
        rt.sizeDelta = sizeOverride ?? new Vector2(420, 70);
        rt.anchoredPosition = Vector2.zero;
        CreateText(go.transform, name + "Text", label, 24, TextAnchor.MiddleCenter, new Vector2(0.5f, 0.5f), rt.sizeDelta, Color.white);
        return go;
    }

    private static GameObject CreateText(Transform parent, string name, string text, int fontSize, TextAnchor alignment,
        Vector2 anchor, Vector2 size, Color color, Vector2? anchoredPosition = null)
    {
        GameObject go = new GameObject(name);
        go.transform.SetParent(parent, false);
        Text txt = go.AddComponent<Text>();
        txt.font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
        txt.text = text;
        txt.fontSize = fontSize;
        txt.alignment = alignment;
        txt.color = color;
        txt.fontStyle = FontStyle.Bold;
        RectTransform rt = txt.rectTransform;
        rt.anchorMin = anchor;
        rt.anchorMax = anchor;
        rt.sizeDelta = size;
        rt.anchoredPosition = anchoredPosition ?? Vector2.zero;
        return go;
    }

    private static void EnsureFolder(string folder)
    {
        if (AssetDatabase.IsValidFolder(folder)) return;
        string[] parts = folder.Split('/');
        string current = parts[0];
        for (int i = 1; i < parts.Length; i++)
        {
            string next = current + "/" + parts[i];
            if (!AssetDatabase.IsValidFolder(next))
            {
                AssetDatabase.CreateFolder(current, parts[i]);
            }
            current = next;
        }
    }

    private static void AddTagIfMissing(string tag)
    {
        SerializedObject tagManager = new SerializedObject(AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/TagManager.asset")[0]);
        SerializedProperty tagsProp = tagManager.FindProperty("tags");
        for (int i = 0; i < tagsProp.arraySize; i++)
        {
            SerializedProperty t = tagsProp.GetArrayElementAtIndex(i);
            if (t.stringValue == tag) return;
        }
        tagsProp.InsertArrayElementAtIndex(tagsProp.arraySize);
        tagsProp.GetArrayElementAtIndex(tagsProp.arraySize - 1).stringValue = tag;
        tagManager.ApplyModifiedProperties();
    }

    private static void SetPrivateField(Object target, string fieldName, object value)
    {
        var flags = System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Public;
        var field = target.GetType().GetField(fieldName, flags);
        if (field != null)
        {
            field.SetValue(target, value);
            EditorUtility.SetDirty(target);
        }
    }
}
#endif
