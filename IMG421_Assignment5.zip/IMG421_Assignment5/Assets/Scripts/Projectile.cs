using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Rigidbody))]
public class Projectile : MonoBehaviour
{
    private const int LOOKBACK_COUNT = 10;
    private static readonly List<Projectile> PROJECTILES = new List<Projectile>();

    [SerializeField] private bool _awake = true;
    public bool awake
    {
        get => _awake;
        private set => _awake = value;
    }

    private Vector3 prevPos;
    private readonly List<float> deltas = new List<float>();
    private Rigidbody rigid;
    private TrailRenderer trail;
    private ParticleSystem flightParticles;
    private bool impactLocked;
    private bool expiring;
    private float activeFlightTime;
    private float lowSpeedTime;

    [SerializeField] private float maxFlightSeconds = 6.5f;
    [SerializeField] private float lowSpeedThreshold = 0.45f;
    [SerializeField] private float lowSpeedTimeout = 1.1f;
    [SerializeField] private float cleanupDelay = 0.35f;

    private void Start()
    {
        rigid = GetComponent<Rigidbody>();
        rigid.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
        rigid.interpolation = RigidbodyInterpolation.Interpolate;
        rigid.drag = 0.06f;
        rigid.angularDrag = 0.12f;
        awake = true;
        prevPos = new Vector3(1000, 1000, 0);
        deltas.Add(1000);
        EnsureProjectilePhysicsMaterial();
        EnsureProjectileSprite();
        EnsureTrail();
        EnsureFlightParticles();
        RuntimeFeedback.EnsureExists();
        PROJECTILES.Add(this);
    }

    private void FixedUpdate()
    {
        if (rigid == null || rigid.isKinematic || !awake)
        {
            if (flightParticles != null && flightParticles.isPlaying)
            {
                flightParticles.Stop(true, ParticleSystemStopBehavior.StopEmitting);
            }
            return;
        }

        float speed = rigid.velocity.magnitude;
        activeFlightTime += Time.fixedDeltaTime;

        if (flightParticles != null)
        {
            if (speed > 1.2f)
            {
                if (!flightParticles.isPlaying) flightParticles.Play();
            }
            else if (flightParticles.isPlaying)
            {
                flightParticles.Stop(true, ParticleSystemStopBehavior.StopEmitting);
            }
        }

        if (activeFlightTime >= maxFlightSeconds)
        {
            ForceProjectileStop(true);
            return;
        }

        if (speed <= lowSpeedThreshold)
        {
            lowSpeedTime += Time.fixedDeltaTime;
            if (lowSpeedTime >= lowSpeedTimeout)
            {
                ForceProjectileStop(true);
                return;
            }
        }
        else
        {
            lowSpeedTime = 0f;
        }

        Vector3 deltaV3 = transform.position - prevPos;
        deltas.Add(deltaV3.magnitude);
        prevPos = transform.position;

        while (deltas.Count > LOOKBACK_COUNT)
        {
            deltas.RemoveAt(0);
        }

        float maxDelta = 0;
        foreach (float f in deltas)
        {
            if (f > maxDelta) maxDelta = f;
        }

        if (maxDelta <= Physics.sleepThreshold)
        {
            ForceProjectileStop(true);
        }
    }

    private void ForceProjectileStop(bool destroyAfterStop)
    {
        if (expiring) return;
        expiring = true;
        awake = false;
        activeFlightTime = 0f;
        lowSpeedTime = 0f;

        if (rigid != null)
        {
            rigid.velocity = Vector3.zero;
            rigid.angularVelocity = Vector3.zero;
            rigid.isKinematic = true;
            rigid.Sleep();
        }

        if (trail != null)
        {
            trail.emitting = false;
            trail.Clear();
        }

        if (flightParticles != null)
        {
            flightParticles.Stop(true, ParticleSystemStopBehavior.StopEmittingAndClear);
        }

        if (FollowCam.POI == gameObject)
        {
            FollowCam.POI = null;
        }

        if (destroyAfterStop)
        {
            Destroy(gameObject, cleanupDelay);
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (rigid == null || rigid.isKinematic) return;
        bool isBreakable = collision.collider != null && collision.collider.GetComponent<BreakableGlass>() != null;
        bool isBounce = HasBounceSurfaceTag(collision.collider);
        Vector3 hitPoint = collision.contactCount > 0 ? collision.GetContact(0).point : transform.position;

        if (!impactLocked)
        {
            impactLocked = true;
            Invoke(nameof(UnlockImpact), 0.04f);
            if (isBreakable)
            {
                RuntimeFeedback.SpawnImpact(hitPoint, RuntimeFeedback.ImpactKind.Breakable);
            }
            else if (isBounce)
            {
                RuntimeFeedback.SpawnImpact(hitPoint, RuntimeFeedback.ImpactKind.Bounce);
                RuntimeFeedback.PlayBounceHit();
            }
            else
            {
                RuntimeFeedback.SpawnImpact(hitPoint, RuntimeFeedback.ImpactKind.Solid);
                RuntimeFeedback.PlayWallHit();
            }
        }

        if (!isBounce) return;

        Vector3 incoming = rigid.velocity;
        if (incoming.sqrMagnitude < 0.01f || collision.contactCount == 0) return;

        Vector3 normal = collision.GetContact(0).normal;
        Vector3 reflected = Vector3.Reflect(incoming, normal);
        float speed = incoming.magnitude;
        float boostedSpeed = Mathf.Clamp(speed * 1.07f, 0f, 32f);
        rigid.velocity = reflected.normalized * boostedSpeed;
    }

    private void UnlockImpact()
    {
        impactLocked = false;
    }

    private static bool HasBounceSurfaceTag(Component component)
    {
        if (component == null) return false;
        GameObject go = component.gameObject;
        if (go == null) return false;
        try
        {
            return go.tag == "BounceSurface";
        }
        catch (UnityException)
        {
            return false;
        }
    }

    private void OnDestroy()
    {
        PROJECTILES.Remove(this);
    }

    private void EnsureProjectilePhysicsMaterial()
    {
        Collider col = GetComponent<Collider>();
        if (col == null) return;
        PhysicMaterial mat = new PhysicMaterial("RuntimeProjectile")
        {
            bounciness = 0.35f,
            dynamicFriction = 0.05f,
            staticFriction = 0.05f,
            bounceCombine = PhysicMaterialCombine.Maximum,
            frictionCombine = PhysicMaterialCombine.Minimum
        };
        col.material = mat;
    }

    private void EnsureProjectileSprite()
    {
        BillboardSpriteVisual visual = GetComponent<BillboardSpriteVisual>();
        if (visual == null) visual = gameObject.AddComponent<BillboardSpriteVisual>();
        visual.Configure("GameBuild/Art/projectile", new Vector2(0.95f, 0.95f), 20, true);
        visual.SetTint(new Color(0.28f, 1f, 0.34f, 1f));
        if (gameObject.GetComponent<ProjectileSpinVisual>() == null)
        {
            gameObject.AddComponent<ProjectileSpinVisual>();
        }
    }

    private void EnsureTrail()
    {
        trail = GetComponent<TrailRenderer>();
        if (trail == null) trail = gameObject.AddComponent<TrailRenderer>();
        Shader shader = Shader.Find("Sprites/Default") ?? Shader.Find("Standard");
        Material mat = new Material(shader);
        mat.color = new Color(0.32f, 1f, 0.38f, 0.95f);
        trail.material = mat;
        trail.time = 0.45f;
        trail.startWidth = 0.32f;
        trail.endWidth = 0.08f;
        trail.minVertexDistance = 0.03f;
        trail.emitting = true;
        trail.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
        trail.receiveShadows = false;
    }

    private void EnsureFlightParticles()
    {
        flightParticles = GetComponentInChildren<ParticleSystem>();
        if (flightParticles != null && flightParticles.gameObject.name == "FlightFX") return;

        GameObject fx = new GameObject("FlightFX");
        fx.transform.SetParent(transform, false);
        fx.transform.localPosition = Vector3.zero;
        flightParticles = fx.AddComponent<ParticleSystem>();

        var main = flightParticles.main;
        main.playOnAwake = false;
        main.loop = true;
        main.startLifetime = 0.4f;
        main.startSpeed = 0.18f;
        main.startSize = 0.14f;
        main.simulationSpace = ParticleSystemSimulationSpace.Local;
        main.maxParticles = 100;

        var emission = flightParticles.emission;
        emission.rateOverTime = 54f;

        var shape = flightParticles.shape;
        shape.enabled = true;
        shape.shapeType = ParticleSystemShapeType.Sphere;
        shape.radius = 0.07f;

        var colorOverLifetime = flightParticles.colorOverLifetime;
        colorOverLifetime.enabled = true;
        Gradient gradient = new Gradient();
        gradient.SetKeys(
            new[]
            {
                new GradientColorKey(new Color(0.78f, 1f, 0.46f), 0f),
                new GradientColorKey(new Color(0.26f, 0.95f, 0.34f), 0.38f),
                new GradientColorKey(new Color(0.06f, 0.72f, 0.22f), 1f)
            },
            new[]
            {
                new GradientAlphaKey(0f, 0f),
                new GradientAlphaKey(0.95f, 0.12f),
                new GradientAlphaKey(0.08f, 0.82f),
                new GradientAlphaKey(0f, 1f)
            });
        colorOverLifetime.color = new ParticleSystem.MinMaxGradient(gradient);

        var sizeOverLifetime = flightParticles.sizeOverLifetime;
        sizeOverLifetime.enabled = true;
        AnimationCurve curve = new AnimationCurve();
        curve.AddKey(0f, 0.3f);
        curve.AddKey(0.3f, 1f);
        curve.AddKey(1f, 0f);
        sizeOverLifetime.size = new ParticleSystem.MinMaxCurve(1f, curve);

        var velocityOverLifetime = flightParticles.velocityOverLifetime;
        velocityOverLifetime.enabled = true;
        velocityOverLifetime.space = ParticleSystemSimulationSpace.Local;
        velocityOverLifetime.x = new ParticleSystem.MinMaxCurve(-0.12f, 0.12f);
        velocityOverLifetime.y = new ParticleSystem.MinMaxCurve(-0.12f, 0.12f);
        velocityOverLifetime.z = new ParticleSystem.MinMaxCurve(-1.4f, -0.6f);

        var trails = flightParticles.trails;
        trails.enabled = true;
        trails.mode = ParticleSystemTrailMode.PerParticle;
        trails.lifetime = 0.18f;
        trails.dieWithParticles = true;
        trails.sizeAffectsWidth = true;
        trails.inheritParticleColor = true;

        var renderer = flightParticles.GetComponent<ParticleSystemRenderer>();
        renderer.renderMode = ParticleSystemRenderMode.Billboard;
        renderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
        renderer.receiveShadows = false;
    }

    public static void DESTROY_PROJECTILES()
    {
        for (int i = PROJECTILES.Count - 1; i >= 0; i--)
        {
            if (PROJECTILES[i] != null)
            {
                Destroy(PROJECTILES[i].gameObject);
            }
        }
    }

    public static bool AnyProjectileMoving()
    {
        for (int i = 0; i < PROJECTILES.Count; i++)
        {
            Projectile projectile = PROJECTILES[i];
            if (projectile == null) continue;
            if (!projectile.awake) continue;
            return true;
        }
        return false;
    }
}
