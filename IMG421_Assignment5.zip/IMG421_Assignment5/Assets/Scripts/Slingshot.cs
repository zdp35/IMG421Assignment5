using UnityEngine;

public class Slingshot : MonoBehaviour
{
    [Header("Inscribed")]
    public GameObject projectilePrefab;
    public float velocityMult = 10f;
    public GameObject projLinePrefab;
    public AudioClip launchClip;

    [Header("Dynamic")]
    public GameObject launchPoint;
    public Vector3 launchPos;
    public GameObject projectile;
    public bool aimingMode;

    [Header("Aim Preview")]
    public int trajectorySteps = 28;
    public float trajectoryTimeStep = 0.08f;
    public Color trajectoryColor = new Color(0.35f, 1f, 0.95f, 0.9f);

    private LineRenderer trajectoryLine;

    private void Awake()
    {
        velocityMult = Mathf.Clamp(velocityMult, 7.5f, 10.25f);

        Transform launchPointTrans = transform.Find("LaunchPoint");
        launchPoint = launchPointTrans.gameObject;
        launchPoint.SetActive(false);
        launchPos = launchPointTrans.position;
        if (GetComponent<IdleBobAnimation>() == null)
        {
            gameObject.AddComponent<IdleBobAnimation>();
        }
    }

    private void Update()
    {
        if (!aimingMode)
        {
            if (trajectoryLine != null) trajectoryLine.enabled = false;
            return;
        }

        Vector3 mousePos2D = Input.mousePosition;
        mousePos2D.z = -Camera.main.transform.position.z;
        Vector3 mousePos3D = Camera.main.ScreenToWorldPoint(mousePos2D);
        Vector3 mouseDelta = mousePos3D - launchPos;
        float maxMagnitude = GetComponent<SphereCollider>().radius;

        if (mouseDelta.magnitude > maxMagnitude)
        {
            mouseDelta.Normalize();
            mouseDelta *= maxMagnitude;
        }

        Vector3 projPos = launchPos + mouseDelta;
        projectile.transform.position = projPos;
        UpdateTrajectoryPreview(mouseDelta);

        if (Input.GetMouseButtonUp(0))
        {
            aimingMode = false;
            Rigidbody projRB = projectile.GetComponent<Rigidbody>();
            projRB.isKinematic = false;
            projRB.collisionDetectionMode = CollisionDetectionMode.Continuous;
            Vector3 launchVelocity = -mouseDelta * velocityMult;
            launchVelocity.y += 0.32f;
            projRB.velocity = launchVelocity;

            if (FollowCam.S != null)
            {
                FollowCam.SWITCH_VIEW(FollowCam.eView.slingshot);
                FollowCam.POI = projectile;
            }

            if (projLinePrefab != null)
            {
                Instantiate(projLinePrefab, projectile.transform);
            }

            if (launchClip != null)
            {
                AudioSource.PlayClipAtPoint(launchClip, transform.position);
            }
            RuntimeFeedback.PlayLaunch();

            if (trajectoryLine != null) trajectoryLine.enabled = false;
            projectile = null;

            if (GameSceneController.Instance != null)
            {
                GameSceneController.Instance.RegisterShotFired();
            }
        }
    }

    private void OnMouseEnter()
    {
        if (GameSceneController.Instance != null && !GameSceneController.Instance.CanShoot()) return;
        launchPoint.SetActive(true);
    }

    private void OnMouseExit()
    {
        launchPoint.SetActive(false);
    }

    private void OnMouseDown()
    {
        if (GameSceneController.Instance != null && !GameSceneController.Instance.CanShoot()) return;
        if (Projectile.AnyProjectileMoving()) return;

        aimingMode = true;
        projectile = Instantiate(projectilePrefab);
        projectile.transform.position = launchPos;
        projectile.GetComponent<Rigidbody>().isKinematic = true;
        EnsureTrajectoryLine();
        if (trajectoryLine != null) trajectoryLine.enabled = true;
    }

    private void EnsureTrajectoryLine()
    {
        if (trajectoryLine != null) return;

        GameObject lineGo = new GameObject("TrajectoryPreview");
        lineGo.transform.SetParent(transform, false);
        trajectoryLine = lineGo.AddComponent<LineRenderer>();
        trajectoryLine.useWorldSpace = true;
        trajectoryLine.loop = false;
        trajectoryLine.positionCount = trajectorySteps;
        trajectoryLine.material = new Material(Shader.Find("Sprites/Default"));
        trajectoryLine.startColor = trajectoryColor;
        trajectoryLine.endColor = new Color(trajectoryColor.r, trajectoryColor.g, trajectoryColor.b, 0.15f);
        trajectoryLine.startWidth = 0.12f;
        trajectoryLine.endWidth = 0.04f;
        trajectoryLine.numCapVertices = 6;
        trajectoryLine.sortingOrder = 35;
        trajectoryLine.enabled = false;
    }

    private void UpdateTrajectoryPreview(Vector3 mouseDelta)
    {
        EnsureTrajectoryLine();
        if (trajectoryLine == null) return;

        Vector3 initialVelocity = -mouseDelta * velocityMult;
        initialVelocity.y += 0.32f;

        trajectoryLine.positionCount = trajectorySteps;
        Vector3 gravity = Physics.gravity;
        for (int i = 0; i < trajectorySteps; i++)
        {
            float t = i * trajectoryTimeStep;
            Vector3 point = launchPos + initialVelocity * t + 0.5f * gravity * t * t;
            trajectoryLine.SetPosition(i, point);
        }
        trajectoryLine.enabled = true;
    }
}
